# AWR Copilot Participant

Ask questions about Oracle AWR reports **directly inside GitHub Copilot Chat** using `@awr`.

---

## How it works

```
AWR HTML file
     │
     ▼ awr-parser.ts
  130 chunks (~400 tokens each, labelled by section)
     │
     ▼ retriever.ts
  TF-IDF cosine similarity + Oracle keyword boosting
     │
     ▼ token-budget.ts
  Hard cap: 7 000 tokens total → greedily fills with best chunks
     │
     ▼ Copilot LM API (gpt-4o via your existing Copilot subscription)
  Streamed answer in the Chat panel
```

**Why no timeouts?**
The token budget is computed *before* the API call. The retriever only selects chunks that fit. The model never receives more tokens than the budget allows — no truncation, no timeouts.

---

## Requirements

- VS Code ≥ 1.90
- **GitHub Copilot Chat** extension installed and signed in (uses your existing subscription — no separate API key needed)

---

## Install

```
Extensions (Ctrl+Shift+X) → ⋯ → Install from VSIX → awr-copilot-participant-0.1.0.vsix
```

---

## Usage

Open **Copilot Chat** (`Ctrl+Alt+I`) and type:

| Command | What it does |
|---|---|
| `@awr /load` | Pick an AWR `.html` file — parses & indexes it |
| `@awr /summary` | Show report metadata + indexed sections |
| `@awr /top sql` | Top SQL statements by elapsed time |
| `@awr /top waits` | Top foreground wait events |
| `@awr /top io` | I/O stats by tablespace/file |
| `@awr /top latch` | Latch contention |
| `@awr /top memory` | SGA/PGA memory breakdown |
| `@awr /clear` | Unload the report |
| `@awr <any question>` | Freeform question about the report |

### Example questions

```
@awr what are the top wait events and what do they mean?
@awr which SQL has the most elapsed time and how can I tune it?
@awr is there any latch contention? what latches are hot?
@awr what is the hard parse rate and is it a problem?
@awr what does the DB Time vs CPU time ratio tell us?
@awr are there I/O bottlenecks on any tablespace?
@awr explain the top 3 performance issues in this report
```

---

## Token budget (anti-timeout design)

| Budget slot | Tokens |
|---|---|
| System prompt + metadata | ~550 |
| User question | ~100 |
| Reserve (Copilot overhead) | ~350 |
| **Available for AWR context** | **~6 000** |

The retriever fills exactly this budget with the highest-ranked chunks.
If a question is very broad, only the top-N best-fit chunks are sent.
The response always arrives — no hanging, no context-length errors.

---

## Building from source

```bash
npm install
npm run compile
npm run package
# → awr-copilot-participant-0.1.0.vsix
```
