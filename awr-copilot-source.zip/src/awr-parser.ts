/**
 * awr-parser.ts
 * Parses Oracle AWR HTML into structured chunks + metadata.
 */

export interface AwrChunk {
  id: string;
  section: string;
  subsection: string;
  content: string;
  tokens: number;          // approximate token count
  keywords: string[];
}

export interface AwrMetadata {
  dbName: string;
  instanceName: string;
  snapRange: string;
  beginTime: string;
  endTime: string;
  elapsedMinutes: string;
  dbTime: string;
  hostName: string;
  platform: string;
  cpuCount: string;
  sgaSize: string;
}

// ── Utilities ─────────────────────────────────────────────────────────────────

export function stripHtml(html: string): string {
  return html
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Rough token estimate: ~4 chars per token (GPT/Claude rule of thumb) */
export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4);
}

// ── Metadata ──────────────────────────────────────────────────────────────────

function parseTableCells(tableHtml: string): { headers: string[]; rows: string[][] } {
  const headers: string[] = [];
  const thRx = /<th[^>]*>([\s\S]*?)<\/th>/gi;
  let m: RegExpExecArray | null;
  while ((m = thRx.exec(tableHtml)) !== null) { headers.push(stripHtml(m[1]).trim()); }

  const rows: string[][] = [];
  const trRx = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  while ((m = trRx.exec(tableHtml)) !== null) {
    const cells: string[] = [];
    const tdRx = /<td[^>]*>([\s\S]*?)<\/td>/gi;
    let td: RegExpExecArray | null;
    while ((td = tdRx.exec(m[1])) !== null) { cells.push(stripHtml(td[1]).trim()); }
    if (cells.length) { rows.push(cells); }
  }
  return { headers, rows };
}

export function extractMetadata(html: string): AwrMetadata {
  const meta: AwrMetadata = {
    dbName: '', instanceName: '', snapRange: '',
    beginTime: '', endTime: '', elapsedMinutes: '',
    dbTime: '', hostName: '', platform: '',
    cpuCount: '', sgaSize: ''
  };

  const tables = html.match(/<table[\s\S]*?<\/table>/gi) ?? [];

  // Table 0: DB Name | DB Id | Instance | Inst num | ...
  if (tables[0]) {
    const { headers, rows } = parseTableCells(tables[0]);
    const row = rows[0] ?? [];
    const idx = (l: string) => headers.findIndex(h => h.toLowerCase().includes(l.toLowerCase()));
    const db = idx('DB Name'), ins = idx('Instance');
    if (db  >= 0 && row[db])  { meta.dbName      = row[db]; }
    if (ins >= 0 && row[ins]) { meta.instanceName = row[ins]; }
  }

  // Table 1: Host Name | Platform | CPUs | ...
  if (tables[1]) {
    const { headers, rows } = parseTableCells(tables[1]);
    const row = rows[0] ?? [];
    const idx = (l: string) => headers.findIndex(h => h.toLowerCase().includes(l.toLowerCase()));
    const hn = idx('Host Name'), pl = idx('Platform'), cp = idx('CPUs');
    if (hn >= 0 && row[hn]) { meta.hostName = row[hn]; }
    if (pl >= 0 && row[pl]) { meta.platform = row[pl]; }
    if (cp >= 0 && row[cp]) { meta.cpuCount = row[cp]; }
  }

  // Table 2: Begin/End snap times + elapsed
  if (tables[2]) {
    const t = tables[2];
    const b = t.match(/Begin\s+Snap[\s\S]{0,400}?(\d{2}-\w{3}-\d{2}\s+\d{2}:\d{2}:\d{2})/i);
    if (b) { meta.beginTime = b[1]; }
    const e = t.match(/End\s+Snap[\s\S]{0,400}?(\d{2}-\w{3}-\d{2}\s+\d{2}:\d{2}:\d{2})/i);
    if (e) { meta.endTime = e[1]; }
    const el = t.match(/([\d,.]+)\s*\(mins\)/i);
    if (el) { meta.elapsedMinutes = el[1]; }
    const db = t.match(/DB\s*Time[\s\S]{0,200}?([\d,.]+)\s*\(mins\)/i);
    if (db) { meta.dbTime = db[1]; }
  }

  // Table 3: Buffer Cache size
  if (tables[3]) {
    const m = tables[3].match(/Buffer\s+Cache:\s*([^<\s,]+)/i);
    if (m) { meta.sgaSize = m[1]; }
  }

  const snapM = html.match(/Snaps[:\s]+(\d+)\s*[-\u2013]\s*(\d+)/i);
  if (snapM) { meta.snapRange = snapM[1] + '-' + snapM[2]; }

  // Title fallbacks
  if (!meta.dbName) {
    const m = html.match(/<title>[^<]*DB:\s*([^,<]+)/i);
    if (m) { meta.dbName = m[1].trim(); }
  }
  if (!meta.instanceName) {
    const m = html.match(/<title>[^<]*Inst:\s*([^,<]+)/i);
    if (m) { meta.instanceName = m[1].trim(); }
  }

  return meta;
}

// ── Chunking ──────────────────────────────────────────────────────────────────

function flattenTable(tableHtml: string): string {
  const { headers, rows } = parseTableCells(tableHtml);
  return rows.map(cells => {
    if (headers.length > 0) {
      return cells.map((c, i) => (headers[i] ?? ('col' + i)) + ': ' + c).join(' | ');
    }
    return cells.join(' | ');
  }).join('\n');
}

function extractKeywords(text: string): string[] {
  const lower = text.toLowerCase();
  const terms = [
    'cpu', 'io', 'wait', 'latch', 'lock', 'buffer', 'redo',
    'sql', 'parse', 'execute', 'fetch', 'commit', 'rollback',
    'checkpoint', 'archiver', 'dbwr', 'lgwr', 'pmon', 'smon',
    'elapsed', 'throughput', 'memory', 'sga', 'pga',
    'shared pool', 'db cache', 'tablespace', 'datafile',
    'enqueue', 'cursor', 'hard parse', 'soft parse',
  ];
  return terms.filter(t => lower.includes(t));
}

/**
 * Parse the AWR HTML into chunks of approximately `targetTokens` each.
 * Each chunk is labelled with its section + subsection for context.
 */
export function parseAwrToChunks(html: string, targetTokens = 400): AwrChunk[] {
  const chunks: AwrChunk[] = [];
  let idx = 0;

  const sectionRx =
    /<h([123])[^>]*class="awr"[^>]*>([\s\S]*?)<\/h\1>([\s\S]*?)(?=<h[123][^>]*class="awr"|$)/gi;

  let currentSection = 'Report Header';
  let m: RegExpExecArray | null;

  while ((m = sectionRx.exec(html)) !== null) {
    const level   = parseInt(m[1], 10);
    const heading = stripHtml(m[2]).trim();
    const body    = m[3];
    if (level <= 2) { currentSection = heading; }

    // Tables
    const tableRx = /<table[\s\S]*?<\/table>/gi;
    let tm: RegExpExecArray | null;
    while ((tm = tableRx.exec(body)) !== null) {
      const text = flattenTable(tm[0]);
      if (!text.trim()) { continue; }
      // Split on newlines first, then batch into token-budget windows
      const lines = text.split('\n').filter(l => l.trim());
      let buf: string[] = [];
      let bufTokens = 0;
      for (const line of lines) {
        const lt = estimateTokens(line);
        if (bufTokens + lt > targetTokens && buf.length > 0) {
          const content = buf.join('\n');
          chunks.push({
            id: 'c' + idx++, section: currentSection, subsection: heading,
            content, tokens: estimateTokens(content), keywords: extractKeywords(content)
          });
          buf = []; bufTokens = 0;
        }
        buf.push(line); bufTokens += lt;
      }
      if (buf.length > 0) {
        const content = buf.join('\n');
        chunks.push({
          id: 'c' + idx++, section: currentSection, subsection: heading,
          content, tokens: estimateTokens(content), keywords: extractKeywords(content)
        });
      }
    }

    // <pre> SQL text blocks
    const preRx = /<pre[^>]*>([\s\S]*?)<\/pre>/gi;
    let pm: RegExpExecArray | null;
    while ((pm = preRx.exec(body)) !== null) {
      const text = stripHtml(pm[1]);
      if (!text.trim()) { continue; }
      chunks.push({
        id: 'c' + idx++, section: currentSection, subsection: heading,
        content: text, tokens: estimateTokens(text), keywords: extractKeywords(text)
      });
    }
  }

  return chunks;
}
