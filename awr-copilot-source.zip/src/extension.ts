/**
 * extension.ts
 *
 * Registers the @awr Copilot Chat participant.
 *
 * Usage in Copilot Chat:
 *   @awr /load                          → pick an AWR .html file
 *   @awr /summary                       → overview of loaded report
 *   @awr /top sql                       → top SQL by elapsed time
 *   @awr /top waits                     → top wait events
 *   @awr what is causing high CPU?      → freeform question
 *   @awr /clear                         → unload the report
 */

import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';

import { parseAwrToChunks, extractMetadata, AwrMetadata } from './awr-parser';
import { Retriever } from './retriever';
import { contextBudget, metadataBlock, SYSTEM_PROMPT } from './token-budget';

// ── Singleton state ───────────────────────────────────────────────────────────

const retriever = new Retriever();
let metadata: AwrMetadata | null = null;
let loadedFile = '';

// ── Activation ────────────────────────────────────────────────────────────────

export function activate(context: vscode.ExtensionContext) {

  // ── Register @awr chat participant ────────────────────────────────────────
  const participant = vscode.chat.createChatParticipant(
    'awr.analyst',
    handleChatRequest
  );
  participant.iconPath = new vscode.ThemeIcon('database');

  // ── Sidebar command (optional shortcut) ──────────────────────────────────
  context.subscriptions.push(
    participant,
    vscode.commands.registerCommand('awr.loadFile', () => loadReport())
  );
}

export function deactivate() {}

// ── Chat handler ──────────────────────────────────────────────────────────────

async function handleChatRequest(
  request: vscode.ChatRequest,
  _ctx: vscode.ChatContext,
  stream: vscode.ChatResponseStream,
  token: vscode.CancellationToken
): Promise<void> {

  // ── /load ─────────────────────────────────────────────────────────────────
  if (request.command === 'load') {
    await loadReport(stream);
    return;
  }

  // ── /clear ────────────────────────────────────────────────────────────────
  if (request.command === 'clear') {
    loadedFile = '';
    metadata = null;
    // rebuild clears the index since we pass empty array
    retriever.build([]);
    stream.markdown('Report cleared from memory.');
    return;
  }

  // Guard: must have a report loaded
  if (!retriever.ready || !metadata) {
    stream.markdown(
      '**No AWR report loaded.**\n\n' +
      'Run `@awr /load` to pick an AWR HTML file, then ask your question.'
    );
    return;
  }

  // ── /summary ──────────────────────────────────────────────────────────────
  if (request.command === 'summary') {
    stream.markdown(buildSummary());
    return;
  }

  // ── /top ──────────────────────────────────────────────────────────────────
  if (request.command === 'top') {
    const topic = request.prompt.trim().toLowerCase() || 'sql';
    const queryMap: Record<string, string> = {
      sql:    'top SQL elapsed time CPU executions SQL_ID',
      waits:  'top wait events foreground background waits',
      io:     'IO stats tablespace file reads writes',
      latch:  'latch contention misses sleeps',
      memory: 'SGA PGA memory usage shared pool buffer cache',
    };
    const mapped = queryMap[topic] ?? `top ${topic}`;
    await answerQuestion(mapped, stream, token);
    return;
  }

  // ── Freeform question ─────────────────────────────────────────────────────
  const question = request.prompt.trim();
  if (!question) {
    stream.markdown(
      'Please ask a question, e.g.:\n' +
      '- `@awr what are the top wait events?`\n' +
      '- `@awr /top sql`\n' +
      '- `@awr /summary`'
    );
    return;
  }

  await answerQuestion(question, stream, token);
}

// ── Core RAG answer ───────────────────────────────────────────────────────────

async function answerQuestion(
  question: string,
  stream: vscode.ChatResponseStream,
  token: vscode.CancellationToken
): Promise<void> {

  if (!metadata) { return; }

  // 1. Compute available token budget for context
  const budget = contextBudget(question);

  // 2. Retrieve best-fitting chunks within budget
  const chunks = retriever.retrieve(question, budget);

  if (chunks.length === 0) {
    stream.markdown('No relevant sections found in the loaded AWR report for that question.');
    return;
  }

  const context = retriever.buildContext(chunks);
  const meta    = metadataBlock(metadata);

  // 3. Build messages for Copilot's LM API
  const messages = [
    vscode.LanguageModelChatMessage.User(
      SYSTEM_PROMPT +
      '\n\n## AWR Report Info\n' + meta +
      '\n\n## Relevant AWR Sections\n' + context +
      '\n\n## Question\n' + question
    ),
  ];

  // 4. Show which sections are being used (transparency)
  const sectionLabels = [...new Set(chunks.map(c => c.subsection))].slice(0, 4);
  stream.markdown(
    `*Searching: ${sectionLabels.join(', ')}*` +
    ` — ${chunks.reduce((s, c) => s + c.tokens, 0)} tokens of context\n\n`
  );

  // 5. Call Copilot's LM (handles auth, model selection, streaming automatically)
  try {
    const [model] = await vscode.lm.selectChatModels({
      vendor: 'copilot',
      family: 'gpt-4o',
    });

    if (!model) {
      stream.markdown('⚠️ No Copilot model available. Make sure GitHub Copilot Chat is installed and signed in.');
      return;
    }

    const response = await model.sendRequest(messages, {}, token);

    for await (const chunk of response.text) {
      if (token.isCancellationRequested) { break; }
      stream.markdown(chunk);
    }

  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);

    // Friendly guidance for common errors
    if (msg.includes('off_topic') || msg.includes('content_filter')) {
      stream.markdown('⚠️ Copilot filtered this request. Try rephrasing your question.');
    } else if (msg.includes('rate') || msg.includes('quota')) {
      stream.markdown('⚠️ Rate limit hit. Wait a moment and try again.');
    } else if (msg.includes('token') || msg.includes('length')) {
      stream.markdown(
        '⚠️ Context too large even after trimming. Try a more specific question, e.g.:\n' +
        '`@awr what is the single biggest wait event?`'
      );
    } else {
      stream.markdown(`⚠️ Error: ${msg}`);
    }
  }
}

// ── Load report ───────────────────────────────────────────────────────────────

async function loadReport(stream?: vscode.ChatResponseStream): Promise<void> {
  const uris = await vscode.window.showOpenDialog({
    canSelectMany: false,
    filters: { 'AWR HTML Report': ['html', 'htm'] },
    title: 'Select AWR Report HTML file',
  });

  if (!uris?.length) {
    stream?.markdown('No file selected.');
    return;
  }

  const filePath = uris[0].fsPath;
  loadedFile = path.basename(filePath);

  stream?.markdown(`Loading **${loadedFile}**…`);

  try {
    const html = fs.readFileSync(filePath, 'utf-8');

    // Parse + index
    const chunks = parseAwrToChunks(html, 400);  // ~400 token chunks
    retriever.build(chunks);
    metadata = extractMetadata(html);

    const msg =
      `✅ **${loadedFile}** loaded and indexed.\n\n` +
      `- **DB:** ${metadata.dbName}  **Instance:** ${metadata.instanceName}\n` +
      `- **Period:** ${metadata.beginTime} → ${metadata.endTime}` +
      ` (${metadata.elapsedMinutes} mins, DB Time: ${metadata.dbTime} mins)\n` +
      `- **Host:** ${metadata.hostName}  **Platform:** ${metadata.platform}  **CPUs:** ${metadata.cpuCount}\n` +
      `- **Indexed:** ${retriever.size} chunks\n\n` +
      `Now ask anything, e.g. \`@awr what are the top wait events?\``;

    if (stream) {
      stream.markdown(msg);
    } else {
      vscode.window.showInformationMessage(
        `AWR report loaded: ${loadedFile} (${retriever.size} chunks indexed)`
      );
    }

  } catch (err) {
    const msg = `Failed to load report: ${err instanceof Error ? err.message : String(err)}`;
    if (stream) { stream.markdown('❌ ' + msg); }
    else { vscode.window.showErrorMessage(msg); }
  }
}

// ── Summary helper ────────────────────────────────────────────────────────────

function buildSummary(): string {
  if (!metadata) { return 'No report loaded.'; }
  return [
    `## AWR Report Summary`,
    `**File:** ${loadedFile}`,
    '',
    `| Field | Value |`,
    `|---|---|`,
    `| DB Name | ${metadata.dbName} |`,
    `| Instance | ${metadata.instanceName} |`,
    `| Host | ${metadata.hostName} |`,
    `| Platform | ${metadata.platform} |`,
    `| CPUs | ${metadata.cpuCount} |`,
    `| Snap Range | ${metadata.snapRange} |`,
    `| Begin | ${metadata.beginTime} |`,
    `| End | ${metadata.endTime} |`,
    `| Elapsed | ${metadata.elapsedMinutes} mins |`,
    `| DB Time | ${metadata.dbTime} mins |`,
    `| Buffer Cache | ${metadata.sgaSize} |`,
    '',
    `**Indexed sections:**`,
    retriever.sectionIndex(),
    '',
    `**Try:**`,
    `- \`@awr what are the top wait events?\``,
    `- \`@awr /top sql\``,
    `- \`@awr are there any latch contention issues?\``,
    `- \`@awr what is the DB CPU vs DB Time ratio?\``,
  ].join('\n');
}
