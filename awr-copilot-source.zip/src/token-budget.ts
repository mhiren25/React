/**
 * token-budget.ts
 *
 * Centralised token budget manager.
 *
 * Copilot Chat has a context window limit (~8 k–16 k tokens depending on model).
 * Exceeding it causes either truncation or a timeout/error.
 *
 * Budget breakdown (conservative defaults):
 *   System prompt    ~  400 tokens  (fixed)
 *   Metadata block   ~  150 tokens  (fixed)
 *   User question    ~  100 tokens  (dynamic, estimated)
 *   Reserve          ~  350 tokens  (Copilot overhead + safety margin)
 *   ─────────────────────────────────────────
 *   Available for    = totalBudget − 1 000
 *   AWR context
 *
 * The retriever is given exactly this remaining budget and fills it greedily
 * with the highest-ranked chunks, so we never go over.
 */

import { estimateTokens } from './awr-parser';

export const TOTAL_TOKEN_BUDGET = 7_000;   // safe for all Copilot models
const FIXED_OVERHEAD            = 1_000;   // system prompt + metadata + reserve

export function contextBudget(question: string): number {
  const questionTokens = estimateTokens(question);
  const remaining = TOTAL_TOKEN_BUDGET - FIXED_OVERHEAD - questionTokens;
  return Math.max(remaining, 500); // always leave at least 500 for context
}

/** Format the metadata block — kept small on purpose */
export function metadataBlock(meta: {
  dbName: string; instanceName: string; snapRange: string;
  beginTime: string; endTime: string; elapsedMinutes: string;
  dbTime: string; hostName: string; platform: string; cpuCount: string;
}): string {
  return [
    `DB: ${meta.dbName}  Instance: ${meta.instanceName}  Snaps: ${meta.snapRange}`,
    `Period: ${meta.beginTime} → ${meta.endTime}  (${meta.elapsedMinutes} mins elapsed, ${meta.dbTime} mins DB Time)`,
    `Host: ${meta.hostName}  Platform: ${meta.platform}  CPUs: ${meta.cpuCount}`,
  ].join('\n');
}

/** The system prompt sent once per request */
export const SYSTEM_PROMPT = `You are an expert Oracle DBA and AWR performance analyst.
You are given relevant excerpts from an Oracle AWR (Automatic Workload Repository) report.
Answer the user's question using ONLY the provided context.
- Reference specific SQL IDs, wait event names, or metric values from the context.
- Highlight bottlenecks and give concrete tuning recommendations.
- If the context doesn't contain enough information, say so clearly and suggest which AWR section to look at.
- Be concise — use bullet points for lists of issues or recommendations.`;
