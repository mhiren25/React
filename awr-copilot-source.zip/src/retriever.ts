/**
 * retriever.ts
 *
 * In-process TF-IDF retriever with a hard token-budget cap.
 * This is the core of the "RAG without timeout" strategy:
 *   - never send more tokens than the budget allows
 *   - rank by relevance so the BEST chunks fill the budget
 *   - keyword-boost Oracle-specific terms so they aren't buried
 */

import { AwrChunk, estimateTokens } from './awr-parser';

interface Indexed {
  chunk: AwrChunk;
  vec: Map<string, number>;
}

// ── TF helpers ────────────────────────────────────────────────────────────────

function tokenise(text: string): string[] {
  return text.toLowerCase().match(/\b\w[\w.]+\b/g) ?? [];
}

function buildTf(text: string): Map<string, number> {
  const toks = tokenise(text);
  const freq = new Map<string, number>();
  for (const t of toks) { freq.set(t, (freq.get(t) ?? 0) + 1); }
  const max = Math.max(...freq.values(), 1);
  freq.forEach((v, k) => freq.set(k, v / max));
  return freq;
}

function cosine(a: Map<string, number>, b: Map<string, number>): number {
  let dot = 0, na = 0, nb = 0;
  for (const [t, w] of a) { dot += w * (b.get(t) ?? 0); na += w * w; }
  for (const w of b.values()) { nb += w * w; }
  return na && nb ? dot / (Math.sqrt(na) * Math.sqrt(nb)) : 0;
}

// Oracle-specific boosting: multiply score if chunk contains these terms
const BOOST_TERMS: Record<string, number> = {
  'wait':        1.5,
  'latch':       1.5,
  'sql':         1.4,
  'elapsed':     1.4,
  'cpu':         1.3,
  'io':          1.3,
  'parse':       1.3,
  'buffer':      1.2,
  'enqueue':     1.4,
  'sga':         1.2,
  'pga':         1.2,
  'tablespace':  1.2,
  'hard parse':  1.5,
};

// ── Retriever class ───────────────────────────────────────────────────────────

export class Retriever {
  private index: Indexed[] = [];

  build(chunks: AwrChunk[]): void {
    this.index = chunks.map(chunk => ({
      chunk,
      vec: buildTf(chunk.section + ' ' + chunk.subsection + ' ' + chunk.content),
    }));
  }

  get ready(): boolean { return this.index.length > 0; }
  get size(): number   { return this.index.length; }

  /**
   * Retrieve the most relevant chunks that fit inside `tokenBudget`.
   *
   * Strategy:
   *  1. Score all chunks via cosine similarity against the query.
   *  2. Apply Oracle keyword boosts.
   *  3. Fill a token budget greedily from the top — stop before overflow.
   *  4. Always include section headers so Claude has context labels.
   */
  retrieve(query: string, tokenBudget: number): AwrChunk[] {
    if (!this.ready) { return []; }

    const qVec = buildTf(query);

    // Score + boost
    const scored = this.index.map(item => {
      let score = cosine(qVec, item.vec);
      const lower = item.chunk.content.toLowerCase();
      for (const [term, mult] of Object.entries(BOOST_TERMS)) {
        if (lower.includes(term)) { score *= mult; break; }
      }
      // Section-name match bonus
      if (item.chunk.section.toLowerCase().includes(query.toLowerCase().slice(0, 10))) {
        score *= 1.6;
      }
      return { chunk: item.chunk, score };
    });

    scored.sort((a, b) => b.score - a.score);

    // Fill budget
    const selected: AwrChunk[] = [];
    let used = 0;
    for (const { chunk } of scored) {
      if (used + chunk.tokens > tokenBudget) { continue; } // skip, try smaller chunks
      selected.push(chunk);
      used += chunk.tokens;
      if (used >= tokenBudget * 0.9) { break; } // 90% full — stop
    }

    return selected;
  }

  /**
   * Build the context string that gets injected into the Copilot prompt.
   * Prefixes each chunk with its section path so Claude always knows where it came from.
   */
  buildContext(chunks: AwrChunk[]): string {
    return chunks
      .map(c => `### ${c.section} › ${c.subsection}\n${c.content}`)
      .join('\n\n---\n\n');
  }

  /**
   * Return a compact one-liner per section showing what's indexed.
   * Used by /summary command.
   */
  sectionIndex(): string {
    const sections = new Map<string, number>();
    for (const { chunk } of this.index) {
      sections.set(chunk.section, (sections.get(chunk.section) ?? 0) + 1);
    }
    return [...sections.entries()]
      .map(([s, n]) => `- **${s}** (${n} chunk${n > 1 ? 's' : ''})`)
      .join('\n');
  }
}
