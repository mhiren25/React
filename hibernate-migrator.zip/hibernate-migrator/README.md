# Hibernate 5.5 → 7.4 Migration Agent

Automated Python agent that migrates a single Gradle module from Hibernate 5.5 to 7.4.

## Requirements

- Python 3.10+
- Java 17+
- Gradle wrapper (`gradlew`) in the module or a parent directory
- Git
- IntelliJ with GitHub Copilot plugin (for the handoff tasks only)

## Usage

```bash
# Dry run first — see everything it would do without touching any files
python migrate.py --module /path/to/your/module --dry-run

# Full migration
python migrate.py --module /path/to/your/module

# Skip compile check (fix errors manually before committing)
python migrate.py --module /path/to/your/module --skip-compile

# Skip git commit
python migrate.py --module /path/to/your/module --skip-git

# Mechanical transforms only — skip Copilot handoff generation
python migrate.py --module /path/to/your/module --skip-llm
```

## What it does

### Phase 1 — Fully automated (no human needed)

| Step | What |
|---|---|
| T1 | Bumps `hibernate-core`, `hibernate-c3p0`, `hibernate-validator` in `build.gradle` |
| T2 | Renames Oracle dialect to `OracleDialect` in `.properties` and Java config |
| T3 | Replaces `session.save()→persist()`, `update()→merge()`, `delete()→remove()`, `createSQLQuery()→createNativeQuery()` |
| T4 | Fixes `@Where→@SQLRestriction`, flags `@TypeDef`/`@ForeignKey`/`@Index` with TODOs, updates `@Type` syntax |
| T5 | Numbers bare `?` positional params in HQL strings to `?1`, `?2` etc |
| T6 | Scans for Criteria API and UserType blocks — inserts inline TODOs and generates `COPILOT-HANDOFF.md` |
| T7 | Updates c3p0 provider class name, warns on `testConnectionOnCheckin` semantics |
| ✅  | Runs `./gradlew compileJava` — aborts git commit if compile fails |
| 📝  | Git commits all mechanical changes with a descriptive message |

### Phase 2 — IntelliJ Copilot Chat (you do this after the agent finishes)

The agent writes **`COPILOT-HANDOFF.md`** in the module root.

Open it in IntelliJ and work through each task:
1. Open the Java file listed in the task
2. Open the **GitHub Copilot Chat** panel (View → Tool Windows → GitHub Copilot)
3. Copy the pre-written prompt from the handoff file into Copilot Chat
4. Apply the suggestion to the file
5. Delete the `TODO[hibernate-migration]` comment
6. Tick the checkbox in the handoff file

After all tasks done:
```bash
./gradlew compileJava
grep -rn "TODO\[hibernate-migration\]" src/
git add -A && git commit -m "chore: complete LLM rewrites for <module>"
```

## What the agent does NOT touch

- `doWork()` / `CallableStatement` stored procedure calls — API unchanged in H7
- `StatelessSession` — API unchanged in H7
- `javax.validation` → `jakarta.validation` — flagged with TODO if found, check manually

## Project structure

```
migrate.py              # CLI entry point
agent/
  pipeline.py           # Orchestrates all transforms in order
  discovery.py          # Pre-migration scanner
transforms/
  t1_gradle.py          # Gradle version bump
  t2_dialect.py         # Oracle dialect rename
  t3_session_api.py     # Session method replacements
  t4_annotations.py     # @TypeDef/@Where/@Type etc
  t5_hql.py             # HQL positional params
  t6_llm_rewrites.py    # Generates COPILOT-HANDOFF.md + inline TODOs
  t7_c3p0.py            # c3p0 provider class
llm/
  handoff.py            # Handoff file builder (Criteria + UserType extraction)
  copilot.py            # Stub — CLI no longer used
utils/
  console.py            # Coloured output
  files.py              # File discovery and read/write
  gradle.py             # Gradle compile runner
  git.py                # Git stage + commit
```
