"""
Transform 12: StatelessSessionImpl.connection() removed (H7) — lean handoff.

Pattern: code that calls statelessSession.connection() to get a raw JDBC
Connection no longer compiles. Replacement is the doWork() callback pattern,
which is already used elsewhere in this codebase for stored procedures
(see t7/t8 stored procedure handling) — so this is a familiar pattern,
not a new concept for the team.

Lean prompt — no full method dump, just the precise instruction.
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files, files_containing


_TODO = """\
// TODO[hibernate-migration][STATELESS-CONNECTION] .connection() removed in H7.
// See COPILOT-HANDOFF.md — replace with statelessSession.doWork(connection -> {...}).
"""


def _lean_prompt(var_name: str) -> str:
    return (
        f"The variable `{var_name}` is a `StatelessSession`. Its `.connection()` method "
        f"is removed in Hibernate 7 — direct JDBC Connection access is no longer exposed "
        f"this way.\n\n"
        f"Replace the pattern:\n"
        f"  Connection conn = {var_name}.connection();\n"
        f"  // ... JDBC code using conn ...\n\n"
        f"With the doWork() callback pattern:\n"
        f"  {var_name}.doWork(connection -> {{\n"
        f"      // ... same JDBC code, using 'connection' instead of 'conn' ...\n"
        f"  }});\n\n"
        f"If the original code returns a value from the JDBC block, use doReturningWork() instead:\n"
        f"  T result = {var_name}.doReturningWork(connection -> {{\n"
        f"      // ... JDBC code ...\n"
        f"      return someValue;\n"
        f"  }});\n\n"
        f"Apply the minimal change needed — keep all existing JDBC logic exactly as-is, "
        f"only change how the Connection is obtained. Output only the modified method."
    )


def collect_stateless_connection_tasks(module_path: Path, dry_run: bool, console) -> list[dict]:
    tasks = []
    pattern = re.compile(r"(\w+)\s*\.\s*connection\s*\(\s*\)")

    for java_file in find_java_files(module_path):
        content = read_file(java_file)
        if ".connection()" not in content:
            continue

        rel = str(java_file.relative_to(module_path))
        lines = content.split("\n")
        new_lines = []
        file_changed = False

        for i, line in enumerate(lines):
            match = pattern.search(line)
            if match and "TODO[hibernate-migration][STATELESS-CONNECTION]" not in line:
                # Heuristic: only flag if the variable looks like a stateless/session var
                var_name = match.group(1)
                # Skip obvious false positives like jdbcConnection.connection() patterns
                # that might be unrelated DB connection wrappers — still flag but note uncertainty
                indent = " " * (len(line) - len(line.lstrip()))
                for tl in _TODO.strip().split("\n"):
                    new_lines.append(indent + tl)
                file_changed = True

                console.warn(
                    f"{rel}:{i+1}: '{var_name}.connection()' detected — "
                    f"flagged for doWork() migration"
                )

                tasks.append({
                    "kind": "STATELESS-CONNECTION",
                    "file_rel": rel,
                    "line_start": i + 1,
                    "description": f"{var_name}.connection() → doWork() pattern",
                    "prompt": _lean_prompt(var_name),
                    "code_block": "",
                })

            new_lines.append(line)

        if file_changed and not dry_run:
            write_file(java_file, "\n".join(new_lines))

    return tasks


def apply(module_path: Path, dry_run: bool, console) -> tuple[int, list[dict]]:
    tasks = collect_stateless_connection_tasks(module_path, dry_run, console)
    return len(tasks), tasks
