"""
Transform 4: Annotation changes.

Handles:
  @Where(clause=...)  →  @SQLRestriction(...)
  @TypeDef / @TypeDefs  →  removed (flagged for manual review)
  @ForeignKey  →  removed (flagged)
  @Index (org.hibernate.annotations)  →  removed (flagged)
  @Type(type="name")  →  @Type(ClassName.class)  [best effort — flags if unsure]

Also fixes imports for renamed annotations.
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files, files_containing


def _apply_where_rename(content: str, changes: list) -> str:
    """@Where → @SQLRestriction"""
    # Replace @Where(clause = "...") or @Where(clause="...")
    pattern = r'@Where\s*\(\s*clause\s*=\s*'
    replacement = '@SQLRestriction('
    new = re.sub(pattern, replacement, content)
    if new != content:
        changes.append(('@Where(clause=...) → @SQLRestriction(...)', None))
    # Fix import
    new = new.replace(
        "import org.hibernate.annotations.Where;",
        "import org.hibernate.annotations.SQLRestriction;"
    )
    return new


def _apply_typedef_flag(content: str, changes: list) -> str:
    """Flag @TypeDef/@TypeDefs — these are removed and need manual attention."""
    if '@TypeDef' in content or '@TypeDefs' in content:
        # Add a TODO comment above each @TypeDef line
        lines = content.split('\n')
        new_lines = []
        for line in lines:
            if re.search(r'@TypeDefs?\b', line):
                indent = len(line) - len(line.lstrip())
                new_lines.append(' ' * indent +
                    '// TODO[hibernate-migration]: @TypeDef removed in H7 — '
                    'use @Type(ClassName.class) directly on field, remove this definition')
                changes.append(('@TypeDef/@TypeDefs removed in H7 — flagged with TODO', 'MANUAL REVIEW REQUIRED'))
            new_lines.append(line)
        return '\n'.join(new_lines)
    return content


def _apply_type_annotation(content: str, changes: list) -> str:
    """
    @Type(type = "typename") → @Type(TypeName.class)
    Only handles cases where the class name is determinable from the string.
    Flags others with TODO.
    """
    # Pattern: @Type(type = "some.package.ClassName") or @Type(type="ClassName")
    def replace_type(m):
        type_value = m.group(1).strip().strip('"\'')
        # If it looks like a fully qualified class name, extract simple name
        if '.' in type_value:
            simple = type_value.split('.')[-1]
            changes.append((f'@Type(type="{type_value}") → @Type({simple}.class)', None))
            return f'@Type({simple}.class)'
        elif type_value[0].isupper():
            # Already looks like a class name
            changes.append((f'@Type(type="{type_value}") → @Type({type_value}.class)', None))
            return f'@Type({type_value}.class)'
        else:
            # Named type — can't auto-resolve, flag it
            changes.append((
                f'@Type(type="{type_value}") — named type registry removed in H7',
                f'MANUAL REVIEW: replace with @Type(ActualClass.class) for type "{type_value}"'
            ))
            return (f'@Type(/* TODO[hibernate-migration]: named type "{type_value}" '
                    f'registry removed — use @Type(ClassName.class) */ "{type_value}")')

    new = re.sub(r'@Type\s*\(\s*type\s*=\s*(["\'][^"\']+["\'])\s*\)', replace_type, content)
    return new


def _apply_foreignkey_flag(content: str, changes: list) -> str:
    """Flag @ForeignKey (org.hibernate.annotations) — removed in H7."""
    if 'org.hibernate.annotations.ForeignKey' in content or (
            '@ForeignKey' in content and 'org.hibernate.annotations' in content):
        lines = content.split('\n')
        new_lines = []
        for line in lines:
            if '@ForeignKey' in line:
                indent = len(line) - len(line.lstrip())
                new_lines.append(' ' * indent +
                    '// TODO[hibernate-migration]: org.hibernate.annotations.@ForeignKey removed — '
                    'use @jakarta.persistence.ForeignKey or remove if not enforced')
                changes.append(('org.hibernate.annotations.@ForeignKey removed — flagged', 'MANUAL REVIEW'))
            new_lines.append(line)
        return '\n'.join(new_lines)
    return content


def _apply_index_flag(content: str, changes: list) -> str:
    """Flag @Index from org.hibernate.annotations — removed in H7."""
    if 'org.hibernate.annotations.Index' in content:
        content = content.replace(
            'import org.hibernate.annotations.Index;',
            '// TODO[hibernate-migration]: org.hibernate.annotations.Index removed — '
            'use @jakarta.persistence.Index or remove\n'
            '// import org.hibernate.annotations.Index;'
        )
        changes.append(('org.hibernate.annotations.@Index removed — flagged', 'MANUAL REVIEW'))
    return content


def apply(module_path: Path, dry_run: bool, console) -> int:
    changed = 0
    candidates = files_containing(
        find_java_files(module_path),
        '@Where', '@TypeDef', '@Type(', '@ForeignKey',
        'org.hibernate.annotations.Index', 'org.hibernate.annotations.ForeignKey'
    )

    for java_file in candidates:
        original = read_file(java_file)
        content = original
        changes = []

        content = _apply_where_rename(content, changes)
        content = _apply_typedef_flag(content, changes)
        content = _apply_type_annotation(content, changes)
        content = _apply_foreignkey_flag(content, changes)
        content = _apply_index_flag(content, changes)

        rel = java_file.relative_to(module_path)
        for desc, warn in changes:
            if dry_run:
                console.dry(f"{rel}: would change {desc}")
            else:
                console.change(f"{rel}: {desc}")
            if warn:
                console.warn(f"  ↳ {warn}")
            changed += 1

        if not dry_run and content != original:
            write_file(java_file, content)

    return changed
