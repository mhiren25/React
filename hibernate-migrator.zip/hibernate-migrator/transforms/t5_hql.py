"""
Transform 5: HQL positional parameter style.

In H7, JDBC-style positional params (?) must be numbered (?1, ?2, ...).
This transform finds createQuery() calls with bare ? params and numbers them.

Also delegates complex HQL review to Copilot CLI.
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files, files_containing


def _number_positional_params(hql: str) -> tuple[str, bool]:
    """
    Replace bare ? with ?1, ?2, ... in an HQL string.
    Returns (new_hql, was_changed).
    Only replaces ? that are not already ?N.
    """
    counter = [0]

    def replace(m):
        # Skip ?N (already numbered)
        if m.group(0) != '?':
            return m.group(0)
        counter[0] += 1
        return f'?{counter[0]}'

    # Match ? not followed by a digit
    new_hql = re.sub(r'\?(?!\d)', replace, hql)
    return new_hql, new_hql != hql


def _process_file(content: str) -> tuple[str, list[str]]:
    """
    Find string literals passed to createQuery() and fix positional params.
    Handles single and multi-line string literals.
    """
    changes = []

    # Find string literals that contain bare ?
    # Pattern: matches Java string literals (simplified — handles most real cases)
    def fix_string_literal(m):
        literal = m.group(0)
        inner = literal[1:-1]  # strip surrounding quotes
        new_inner, changed = _number_positional_params(inner)
        if changed:
            changes.append(f'HQL positional params numbered: ...{inner[:40]}...')
            return f'"{new_inner}"'
        return literal

    # Only process strings on lines containing createQuery
    lines = content.split('\n')
    new_lines = []
    for line in lines:
        if 'createQuery' in line and '?' in line:
            new_line = re.sub(r'"([^"]*\?[^"]*)"', fix_string_literal, line)
            new_lines.append(new_line)
        else:
            new_lines.append(line)

    return '\n'.join(new_lines), changes


def apply(module_path: Path, dry_run: bool, console) -> int:
    changed = 0
    candidates = files_containing(find_java_files(module_path), 'createQuery')

    for java_file in candidates:
        original = read_file(java_file)

        # Only process files with bare ? in query strings
        if 'createQuery' not in original or '?' not in original:
            continue

        content, changes = _process_file(original)
        rel = java_file.relative_to(module_path)

        for desc in changes:
            if dry_run:
                console.dry(f"{rel}: would fix {desc}")
            else:
                console.change(f"{rel}: {desc}")
            changed += 1

        if not dry_run and content != original:
            write_file(java_file, content)

    return changed
