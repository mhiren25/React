"""
Transform 1: Gradle dependency version bump.

Rules:
- Only replaces versions still on 5.x (old group ID org.hibernate:*)
- Never overwrites a version already on 6.x or 7.x — those were set manually
- Also cleans up hibernate-entitymanager and javax.persistence-api if present
"""

import re
from pathlib import Path
from utils.files import read_file, write_file


H7_VERSION = "7.4.2.Final"
VALIDATOR_VERSION = "9.0.1.Final"


def _is_old_version(version_str: str) -> bool:
    """Return True only if version is on the 5.x line."""
    # Matches versions like 5.5.7.Final, 5.6.0.Final, 5.x.y etc
    return bool(re.match(r"5\.", version_str.strip()))


# Each entry: (match_pattern, new_group_and_artifact, new_version)
# Pattern captures the full dependency string including version.
# We only replace if the captured version starts with 5.
REPLACEMENTS = [
    # hibernate-core: group changed from org.hibernate to org.hibernate.orm
    (
        r"(org\.hibernate:hibernate-core:)([\w.\-]+)",
        "org.hibernate.orm:hibernate-core",
        H7_VERSION,
    ),
    # hibernate-c3p0 → hibernate-hikaricp (group changed + pool swap)
    (
        r"(org\.hibernate(?:\.orm)?:hibernate-c3p0:)([\w.\-]+)",
        "org.hibernate.orm:hibernate-hikaricp",
        H7_VERSION,
    ),
    # hibernate-validator: group changed from org.hibernate to org.hibernate.validator
    (
        r"(org\.hibernate:hibernate-validator:)([\w.\-]+)",
        "org.hibernate.validator:hibernate-validator",
        VALIDATOR_VERSION,
    ),
]

# These are always removed regardless of version — not version-gated
REMOVALS = [
    (
        r"org\.hibernate:hibernate-entitymanager:[^\s'\"]+",
        f"/* REMOVED: hibernate-entitymanager bundled in hibernate-core {H7_VERSION} */",
    ),
    (
        r"javax\.persistence:javax\.persistence-api:[^\s'\"]+",
        "/* REMOVED: javax.persistence-api — check if jakarta.persistence-api needed */",
    ),
]


def apply(module_path: Path, dry_run: bool, console) -> int:
    """Returns count of changes made."""
    build_gradle = module_path / "build.gradle"
    build_gradle_kts = module_path / "build.gradle.kts"

    changed = 0
    for gradle_file in [build_gradle, build_gradle_kts]:
        if not gradle_file.exists():
            continue

        original = read_file(gradle_file)
        content = original

        # Version-gated replacements — only act on 5.x
        for pattern, new_coord, new_version in REPLACEMENTS:
            def _replace(m, _coord=new_coord, _ver=new_version):
                existing_version = m.group(2)
                if _is_old_version(existing_version):
                    return f"{_coord}:{_ver}"
                # Already on 6.x or 7.x — leave untouched
                return m.group(0)

            new_content = re.sub(pattern, _replace, content)
            if new_content != content:
                # Log what changed
                for m in re.finditer(pattern, content):
                    if _is_old_version(m.group(2)):
                        old = m.group(0)
                        new = f"{new_coord}:{new_version}"
                        if dry_run:
                            console.dry(f"build.gradle: would replace '{old}' → '{new}'")
                        else:
                            console.change(f"build.gradle: '{old}' → '{new}'")
                        changed += 1
                content = new_content
            else:
                # Check if it was already on 7.x and skip gracefully
                for m in re.finditer(pattern, content):
                    if not _is_old_version(m.group(2)):
                        console.skip(
                            f"build.gradle: {m.group(0)} already on "
                            f"{m.group(2)} — not overwriting"
                        )

        # Unconditional removals
        for pattern, replacement in REMOVALS:
            new_content = re.sub(pattern, replacement, content)
            if new_content != content:
                matches = re.findall(pattern, content)
                for m in matches:
                    if dry_run:
                        console.dry(f"build.gradle: would remove '{m}'")
                    else:
                        console.change(f"build.gradle: removed '{m}'")
                    changed += 1
                content = new_content

        # Add HikariCP dependency if hibernate-hikaricp is now present but HikariCP is not
        hikari_dep = '    implementation "com.zaxxer:HikariCP:5.1.0"'
        if "hibernate-hikaricp" in content and "HikariCP" not in content:
            content = re.sub(
                r"(hibernate-hikaricp:[^\s'\"]+['\"])",
                r"\1\n" + hikari_dep,
                content,
            )
            if dry_run:
                console.dry("build.gradle: would add com.zaxxer:HikariCP:5.1.0")
            else:
                console.change("build.gradle: added com.zaxxer:HikariCP:5.1.0")
            changed += 1

        if not dry_run and content != original:
            write_file(gradle_file, content)

    return changed
