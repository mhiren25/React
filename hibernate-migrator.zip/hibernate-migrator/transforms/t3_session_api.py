"""
Transform 3: Session API removed method replacements.

Handles:
  session.save(x)          → session.persist(x)
  session.update(x)        → session.merge(x)   [flags return value risk]
  session.saveOrUpdate(x)  → session.merge(x)
  session.delete(x)        → session.remove(x)
  session.createSQLQuery(  → session.createNativeQuery(

Does NOT touch StatelessSession — its API is unchanged in H7.
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files, files_containing


# Each tuple: (search_pattern, replacement, warn_message_or_None)
TRANSFORMS = [
    # session.save(  →  session.persist(
    (
        r"(\bsession\s*\.\s*)save\s*\(",
        r"\1persist(",
        None,
    ),
    # session.update(  →  session.merge(  — warn about return value
    (
        r"(\bsession\s*\.\s*)update\s*\(",
        r"\1merge(",
        "merge() returns a new managed instance — verify callers don't use original object after merge",
    ),
    # session.saveOrUpdate(  →  session.merge(
    (
        r"(\bsession\s*\.\s*)saveOrUpdate\s*\(",
        r"\1merge(",
        "merge() return value — verify caller uses the returned object",
    ),
    # session.delete(  →  session.remove(
    (
        r"(\bsession\s*\.\s*)delete\s*\(",
        r"\1remove(",
        None,
    ),
    # session.createSQLQuery(  →  session.createNativeQuery(
    (
        r"(\bsession\s*\.\s*)createSQLQuery\s*\(",
        r"\1createNativeQuery(",
        "createNativeQuery: consider adding entity class as second arg if result maps to entity",
    ),
]

# Patterns that indicate StatelessSession — skip those lines
STATELESS_PATTERN = re.compile(r"statelessSession|StatelessSession", re.IGNORECASE)


def _transform_file(content: str) -> tuple[str, list[tuple[str, str | None]]]:
    """Apply all session API transforms line by line. Skip StatelessSession lines."""
    lines = content.split("\n")
    changes: list[tuple[str, str | None]] = []
    new_lines = []

    for line in lines:
        # Never touch StatelessSession lines
        if STATELESS_PATTERN.search(line):
            new_lines.append(line)
            continue

        new_line = line
        for pattern, replacement, warn in TRANSFORMS:
            replaced = re.sub(pattern, replacement, new_line)
            if replaced != new_line:
                # Extract what actually changed for logging
                old_match = re.search(pattern, new_line)
                old_text = old_match.group(0) if old_match else pattern
                new_text = re.sub(pattern, replacement, old_text)
                changes.append((f"{old_text.strip()} → {new_text.strip()}", warn))
                new_line = replaced

        new_lines.append(new_line)

    return "\n".join(new_lines), changes


def apply(module_path: Path, dry_run: bool, console) -> int:
    changed = 0
    candidates = files_containing(
        find_java_files(module_path),
        ".save(", ".update(", ".saveOrUpdate(", ".delete(", "createSQLQuery("
    )

    for java_file in candidates:
        original = read_file(java_file)
        content, changes = _transform_file(original)
        rel = java_file.relative_to(module_path)

        for desc, warn in changes:
            if dry_run:
                console.dry(f"{rel}: would change {desc}")
            else:
                console.change(f"{rel}: {desc}")
            if warn:
                console.warn(f"  ↳ {warn}")
            changed += 1

        if not dry_run and content != original:
            write_file(java_file, content)

    return changed
