"""
Transform 8: org.hibernate.SQLQuery → org.hibernate.query.NativeQuery

SQLQuery was deprecated in H5 and fully removed in H6+.
createSQLQuery() rename is already handled in T3.
This transform handles everything else:

  1. Import:  import org.hibernate.SQLQuery
             → import org.hibernate.query.NativeQuery

  2. Type declarations:  SQLQuery query = ...
                        → NativeQuery query = ...
                        (also typed: SQLQuery<MyEntity>)

  3. addScalar() with old Type constants:
       .addScalar("col", Hibernate.STRING)
       .addScalar("col", StandardBasicTypes.STRING)
       → .addScalar("col", String.class)

  4. setResultTransformer() — removed in H7, no direct equivalent.
       Flagged with TODO + added to Copilot handoff.

  5. unwrap(SQLQuery.class) → unwrap(NativeQuery.class)
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files, files_containing


# ── Old Hibernate Type constant → Java class mapping ─────────────────────────
# Covers both Hibernate.XXX (very old) and StandardBasicTypes.XXX (H5)
_TYPE_MAP = {
    # String types
    "Hibernate.STRING":               "String.class",
    "StandardBasicTypes.STRING":      "String.class",
    "Hibernate.TEXT":                 "String.class",
    "StandardBasicTypes.TEXT":        "String.class",
    "Hibernate.CHARACTER":            "Character.class",
    "StandardBasicTypes.CHARACTER":   "Character.class",
    # Numeric types
    "Hibernate.INTEGER":              "Integer.class",
    "StandardBasicTypes.INTEGER":     "Integer.class",
    "Hibernate.LONG":                 "Long.class",
    "StandardBasicTypes.LONG":        "Long.class",
    "Hibernate.SHORT":                "Short.class",
    "StandardBasicTypes.SHORT":       "Short.class",
    "Hibernate.DOUBLE":               "Double.class",
    "StandardBasicTypes.DOUBLE":      "Double.class",
    "Hibernate.FLOAT":                "Float.class",
    "StandardBasicTypes.FLOAT":       "Float.class",
    "Hibernate.BIG_DECIMAL":          "BigDecimal.class",
    "StandardBasicTypes.BIG_DECIMAL": "BigDecimal.class",
    "Hibernate.BIG_INTEGER":          "BigInteger.class",
    "StandardBasicTypes.BIG_INTEGER": "BigInteger.class",
    "Hibernate.BYTE":                 "Byte.class",
    "StandardBasicTypes.BYTE":        "Byte.class",
    # Boolean
    "Hibernate.BOOLEAN":              "Boolean.class",
    "StandardBasicTypes.BOOLEAN":     "Boolean.class",
    "Hibernate.YES_NO":               "Boolean.class",
    "StandardBasicTypes.YES_NO":      "Boolean.class",
    "Hibernate.TRUE_FALSE":           "Boolean.class",
    "StandardBasicTypes.TRUE_FALSE":  "Boolean.class",
    # Date/Time
    "Hibernate.DATE":                 "java.sql.Date.class",
    "StandardBasicTypes.DATE":        "java.sql.Date.class",
    "Hibernate.TIME":                 "java.sql.Time.class",
    "StandardBasicTypes.TIME":        "java.sql.Time.class",
    "Hibernate.TIMESTAMP":            "java.sql.Timestamp.class",
    "StandardBasicTypes.TIMESTAMP":   "java.sql.Timestamp.class",
    # Binary / misc
    "Hibernate.BINARY":               "byte[].class",
    "StandardBasicTypes.BINARY":      "byte[].class",
    "Hibernate.BLOB":                 "java.sql.Blob.class",
    "StandardBasicTypes.BLOB":        "java.sql.Blob.class",
    "Hibernate.CLOB":                 "java.sql.Clob.class",
    "StandardBasicTypes.CLOB":        "java.sql.Clob.class",
}

# Sorted longest-first so longer names match before their prefixes
_TYPE_KEYS_SORTED = sorted(_TYPE_MAP.keys(), key=len, reverse=True)

_RESULT_TRANSFORMER_TODO = (
    "// TODO[hibernate-migration][NATIVE-QUERY] setResultTransformer() removed in H7.\n"
    "// See COPILOT-HANDOFF.md for migration instructions.\n"
)


# ── Per-file transform ────────────────────────────────────────────────────────

def _transform_file(content: str) -> tuple[str, list[tuple[str, str | None]], bool]:
    """
    Returns (new_content, changes, has_result_transformer).
    changes: list of (description, warn_or_None)
    """
    changes: list[tuple[str, str | None]] = []
    has_result_transformer = False
    lines = content.split("\n")
    new_lines = []

    for line in lines:
        new_line = line

        # 1. Import replacement
        if "import org.hibernate.SQLQuery" in new_line:
            new_line = new_line.replace(
                "import org.hibernate.SQLQuery",
                "import org.hibernate.query.NativeQuery",
            )
            changes.append(("import org.hibernate.SQLQuery → import org.hibernate.query.NativeQuery", None))

        # 2. Type declaration: SQLQuery<X> or raw SQLQuery
        #    Match as a type (preceded by space, (, <, or start of declaration)
        #    Replace SQLQuery → NativeQuery preserving any generic parameter
        new_line, n = re.subn(
            r"\bSQLQuery(<[^>]+>)?",
            lambda m: f"NativeQuery{m.group(1) or ''}",
            new_line,
        )
        if n:
            changes.append((f"SQLQuery type → NativeQuery ({n} occurrence(s) on this line)", None))

        # 3. unwrap(SQLQuery.class) → unwrap(NativeQuery.class)
        if "unwrap(SQLQuery.class)" in new_line:
            new_line = new_line.replace("unwrap(SQLQuery.class)", "unwrap(NativeQuery.class)")
            changes.append(("unwrap(SQLQuery.class) → unwrap(NativeQuery.class)", None))

        # 4. addScalar with old Type constants
        for old_type, new_type in _TYPE_MAP.items():
            if old_type in new_line:
                new_line = new_line.replace(old_type, new_type)
                changes.append((
                    f"addScalar type constant {old_type} → {new_type}",
                    None,
                ))

        # 5. setResultTransformer — flag, don't auto-fix
        if "setResultTransformer(" in new_line and "TODO[hibernate-migration]" not in new_line:
            has_result_transformer = True
            indent = " " * (len(new_line) - len(new_line.lstrip()))
            todo = indent + _RESULT_TRANSFORMER_TODO.strip()
            new_lines.append(todo)
            changes.append((
                "setResultTransformer() removed in H7 — flagged with TODO",
                "MANUAL: use stream()/getResultList() + Java stream map, "
                "or a constructor expression in the query. See handoff file.",
            ))

        new_lines.append(new_line)

    return "\n".join(new_lines), changes, has_result_transformer


# ── Handoff task for setResultTransformer ────────────────────────────────────

def _result_transformer_prompt(method_text: str) -> str:
    return (
        "Migrate this code away from Hibernate's removed setResultTransformer() API.\n\n"
        "Context:\n"
        "- setResultTransformer() was removed in Hibernate 6/7\n"
        "- We use pure Hibernate native API, no JPA, no Spring\n"
        "- Database is Oracle\n\n"
        "Migration options (choose the simplest that fits):\n"
        "1. If transforming to a DTO: use a constructor expression in the HQL/SQL "
        "and createNativeQuery(sql, DtoClass.class)\n"
        "2. If transforming to a Map or simple projection: use getResultList() "
        "and map with Java streams\n"
        "3. If using Transformers.aliasToBean(MyClass.class): replace with "
        "createNativeQuery(sql, MyClass.class)\n\n"
        "Rules:\n"
        "- Preserve the exact result structure\n"
        "- Do not change surrounding code beyond what is needed\n"
        "- Output ONLY the migrated code block — no explanation, no markdown fences\n\n"
        "Code to migrate:\n"
        "```java\n"
        f"{method_text}\n"
        "```"
    )


def collect_result_transformer_tasks(
    module_path: Path, java_files: list[Path]
) -> list[dict]:
    """
    Return handoff tasks for every method containing setResultTransformer().
    Called after _transform_file has already inserted TODO comments.
    """
    tasks = []
    for java_file in java_files:
        content = read_file(java_file)
        if "setResultTransformer(" not in content:
            continue
        rel = str(java_file.relative_to(module_path))
        # Extract containing method(s)
        lines = content.split("\n")
        i = 0
        while i < len(lines):
            line = lines[i]
            if re.search(r"\b(public|private|protected)\b.*\{", line):
                depth = line.count("{") - line.count("}")
                start = i
                j = i + 1
                while j < len(lines) and depth > 0:
                    depth += lines[j].count("{") - lines[j].count("}")
                    j += 1
                method_text = "\n".join(lines[start:j])
                if "setResultTransformer(" in method_text:
                    tasks.append({
                        "kind": "NATIVE-QUERY",
                        "file_rel": rel,
                        "line_start": start + 1,
                        "description": "setResultTransformer() removed — migrate result mapping",
                        "prompt": _result_transformer_prompt(method_text),
                        "code_block": method_text,
                    })
                i = j
            else:
                i += 1
    return tasks


# ── Main apply ────────────────────────────────────────────────────────────────

def apply(module_path: Path, dry_run: bool, console) -> tuple[int, list[dict]]:
    """
    Returns (change_count, handoff_tasks).
    handoff_tasks are passed to t6/handoff for setResultTransformer cases.
    """
    changed = 0
    handoff_tasks = []

    candidates = files_containing(
        find_java_files(module_path),
        "SQLQuery", "addScalar", "setResultTransformer", "StandardBasicTypes",
    )

    for java_file in candidates:
        original = read_file(java_file)
        content, changes, has_rt = _transform_file(original)
        rel = java_file.relative_to(module_path)

        for desc, warn in changes:
            if dry_run:
                console.dry(f"{rel}: would change {desc}")
            else:
                console.change(f"{rel}: {desc}")
            if warn:
                console.warn(f"  ↳ {warn}")
            changed += 1

        if not dry_run and content != original:
            write_file(java_file, content)

    # Collect setResultTransformer handoff tasks after files are written
    if not dry_run:
        handoff_tasks = collect_result_transformer_tasks(
            module_path, find_java_files(module_path)
        )
        for t in handoff_tasks:
            console.info(
                f"  [Handoff] NATIVE-QUERY setResultTransformer "
                f"{t['file_rel']}:{t['line_start']}"
            )

    return changed, handoff_tasks
