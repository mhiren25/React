"""
Transform 2: Oracle dialect rename.
Covers .properties files and programmatic config in .java files.
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files


OLD_DIALECTS = [
    "org.hibernate.dialect.Oracle10gDialect",
    "org.hibernate.dialect.Oracle12cDialect",
    "org.hibernate.dialect.Oracle9iDialect",
    "org.hibernate.dialect.OracleLegacyDialect",
]
NEW_DIALECT = "org.hibernate.dialect.OracleDialect"


def _replace_dialects(content: str) -> tuple[str, list[str]]:
    changes = []
    for old in OLD_DIALECTS:
        if old in content:
            content = content.replace(old, NEW_DIALECT)
            changes.append(f"{old} → {NEW_DIALECT}")
    return content, changes


def apply(module_path: Path, dry_run: bool, console) -> int:
    changed = 0

    # .properties and .xml config files
    config_patterns = ["**/*.properties", "**/hibernate.cfg.xml", "**/persistence.xml"]
    for pattern in config_patterns:
        for f in module_path.rglob(pattern.lstrip("**/")):
            if not f.is_file():
                continue
            original = read_file(f)
            content, changes = _replace_dialects(original)
            for c in changes:
                if dry_run:
                    console.dry(f"{f.name}: would replace {c}")
                else:
                    console.change(f"{f.name}: {c}")
                changed += 1
            if not dry_run and content != original:
                write_file(f, content)

    # Java source files (programmatic Configuration)
    for java_file in find_java_files(module_path):
        original = read_file(java_file)
        content, changes = _replace_dialects(original)
        for c in changes:
            rel = java_file.relative_to(module_path)
            if dry_run:
                console.dry(f"{rel}: would replace {c}")
            else:
                console.change(f"{rel}: {c}")
            changed += 1
        if not dry_run and content != original:
            write_file(java_file, content)

    return changed
