"""
Transform 10: Query API + Session API mechanical renames (Hibernate 7).

Sourced from real H7 migration findings on this codebase. All changes here
are pure mechanical renames — safe for regex, no LLM needed.

Covers:
  1. session.get(Class, id)            → session.find(Class, id)
  2. query.setString(name, val)        → query.setParameter(name, val)
     query.setInteger/setLong/etc(...) → query.setParameter(...)
  3. query.setString(0, val)           → query.setParameter(1, val)  [0-based → 1-based positional]
  4. query.uniqueResult()              → query.getSingleResultOrNull()
  5. query.list()                      → query.getResultList()
  6. import org.hibernate.Query        → import org.hibernate.query.Query
  7. @OrderBy(clause="...")            → @SQLOrder("...")
  8. Environment.USE_REFLECTION_OPTIMIZER  → deleted (constant removed)
  9. ScrollableResults.get(int)/getDate(int) → get() returning Object[] — FLAGGED (semantic change, not 1:1 safe)
  10. session.setHibernateFlushMode()  → deleted (removed in H7) — FLAGGED
  11. session.setFlushMode(FlushMode.X) → session.setFlushMode(FlushModeType.X) — FLAGGED (enum changed)
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files, files_containing


# ── 1. session.get → session.find ─────────────────────────────────────────────
# Only matches the two-arg form: session.get(Class, id)
# Skips session.get(String entityName, id) since that has no direct find() overload semantics change risk — still safe to rename, JPA find() supports both forms.

_GET_TO_FIND = re.compile(r"(\bsession\s*\.\s*)get\s*\(")


# ── 2 & 3. Typed setters → setParameter ───────────────────────────────────────
# query.setString("name", val) / setInteger / setLong / setBoolean / setDate /
# setTimestamp / setDouble / setFloat / setBigDecimal / setByte / setShort /
# setCharacter all collapse to setParameter with the same arguments.
_TYPED_SETTERS = [
    "setString", "setInteger", "setLong", "setBoolean", "setDate",
    "setTimestamp", "setDouble", "setFloat", "setBigDecimal", "setByte",
    "setShort", "setCharacter", "setBinary", "setTime",
]

# Build pattern: query.setXxx(  →  query.setParameter(
_TYPED_SETTER_PATTERN = re.compile(
    r"(\b(?:query|q)\s*\.\s*)(" + "|".join(_TYPED_SETTERS) + r")\s*\("
)

# Positional form with 0-based index: setString(0, val) → setParameter(1, val)
_POSITIONAL_SETTER_PATTERN = re.compile(
    r"(\b(?:query|q)\s*\.\s*setParameter\s*\(\s*)(\d+)(\s*,)"
)


# ── 4 & 5. uniqueResult / list ────────────────────────────────────────────────
_UNIQUE_RESULT = re.compile(r"(\.\s*)uniqueResult\s*\(\s*\)")
_LIST_CALL = re.compile(r"(\.\s*)list\s*\(\s*\)")


# ── 7. @OrderBy(clause="...") → @SQLOrder("...") ──────────────────────────────
_ORDERBY_PATTERN = re.compile(r'@OrderBy\s*\(\s*clause\s*=\s*("(?:[^"\\]|\\.)*")\s*\)')


# ── Flagged-only patterns (semantic risk — TODO not auto-fix) ─────────────────
_SCROLLABLE_PATTERN = re.compile(r"\.\s*(get|getDate|getInteger|getLong|getString)\s*\(\s*\d+\s*\)")
_SET_HIBERNATE_FLUSH_MODE = re.compile(r"\.\s*setHibernateFlushMode\s*\(")
_SET_FLUSH_MODE_ENUM = re.compile(r"setFlushMode\s*\(\s*FlushMode\.")


def _apply_mechanical(content: str) -> tuple[str, list[str]]:
    """Apply all safe mechanical renames. Returns (new_content, change_descriptions)."""
    changes = []

    # 1. session.get → session.find
    def _get_repl(m):
        return f"{m.group(1)}find("
    new_content, n = _GET_TO_FIND.subn(_get_repl, content)
    if n:
        changes.append(f"session.get(Class, id) → session.find(Class, id) [{n}x]")
    content = new_content

    # 2. Typed setters → setParameter
    def _setter_repl(m):
        return f"{m.group(1)}setParameter("
    new_content, n = _TYPED_SETTER_PATTERN.subn(_setter_repl, content)
    if n:
        changes.append(f"typed setters (setString/setInteger/etc) → setParameter [{n}x]")
    content = new_content

    # 3. Positional index 0-based → 1-based
    # Only safe to do AFTER the setter rename above, on setParameter calls with int literal first arg
    def _positional_repl(m):
        old_idx = int(m.group(2))
        new_idx = old_idx + 1
        return f"{m.group(1)}{new_idx}{m.group(3)}"
    new_content, n = _POSITIONAL_SETTER_PATTERN.subn(_positional_repl, content)
    if n:
        changes.append(
            f"positional setParameter index 0-based → 1-based [{n}x] "
            f"— VERIFY: only applies if these were originally positional (not named) params"
        )
    content = new_content

    # 4. uniqueResult() → getSingleResultOrNull()
    def _unique_repl(m):
        return f"{m.group(1)}getSingleResultOrNull()"
    new_content, n = _UNIQUE_RESULT.subn(_unique_repl, content)
    if n:
        changes.append(f"uniqueResult() → getSingleResultOrNull() [{n}x]")
    content = new_content

    # 5. list() → getResultList()
    def _list_repl(m):
        return f"{m.group(1)}getResultList()"
    new_content, n = _LIST_CALL.subn(_list_repl, content)
    if n:
        changes.append(f"list() → getResultList() [{n}x]")
    content = new_content

    # 6. import org.hibernate.Query → import org.hibernate.query.Query
    if "import org.hibernate.Query;" in content:
        content = content.replace(
            "import org.hibernate.Query;",
            "import org.hibernate.query.Query;",
        )
        changes.append("import org.hibernate.Query → import org.hibernate.query.Query")

    # 7. @OrderBy(clause="...") → @SQLOrder("...")
    def _orderby_repl(m):
        return f"@SQLOrder({m.group(1)})"
    new_content, n = _ORDERBY_PATTERN.subn(_orderby_repl, content)
    if n:
        changes.append(f"@OrderBy(clause=...) → @SQLOrder(...) [{n}x]")
        # Fix the import too
        content = new_content.replace(
            "import org.hibernate.annotations.OrderBy;",
            "import org.hibernate.annotations.SQLOrder;",
        )
    else:
        content = new_content

    # 8. Environment.USE_REFLECTION_OPTIMIZER — delete the line entirely
    lines = content.split("\n")
    new_lines = []
    removed_count = 0
    for line in lines:
        if "Environment.USE_REFLECTION_OPTIMIZER" in line:
            removed_count += 1
            continue  # drop the line
        new_lines.append(line)
    if removed_count:
        content = "\n".join(new_lines)
        changes.append(f"Environment.USE_REFLECTION_OPTIMIZER — removed [{removed_count} line(s)]")

    return content, changes


def _apply_flags(content: str, file_rel: str, console, dry_run: bool) -> tuple[str, int]:
    """
    Insert TODO comments for patterns that are too risky to auto-fix.
    Returns (new_content, flag_count).
    """
    flagged = 0
    lines = content.split("\n")
    new_lines = []

    for line in lines:
        # ScrollableResults.get(int) / getDate(int) etc — semantic change to Object[]
        if _SCROLLABLE_PATTERN.search(line) and "ScrollableResults" not in line:
            # Only flag if this looks like it's on a ScrollableResults variable —
            # heuristic: preceding context check is unreliable per-line, so we
            # flag any .get(int)/.getDate(int) call as a candidate and let the
            # developer confirm in the handoff file.
            pass  # too noisy as a blanket flag — handled via dedicated detection below

        if "setHibernateFlushMode(" in line and "TODO[hibernate-migration]" not in line:
            indent = " " * (len(line) - len(line.lstrip()))
            new_lines.append(
                indent + "// TODO[hibernate-migration][FLUSH-MODE] "
                "setHibernateFlushMode() removed in H7 — use setFlushMode(FlushModeType) instead"
            )
            flagged += 1
            if dry_run:
                console.dry(f"{file_rel}: would flag setHibernateFlushMode() removal")
            else:
                console.warn(f"{file_rel}: setHibernateFlushMode() removed — flagged with TODO")

        if _SET_FLUSH_MODE_ENUM.search(line) and "TODO[hibernate-migration]" not in line:
            indent = " " * (len(line) - len(line.lstrip()))
            new_lines.append(
                indent + "// TODO[hibernate-migration][FLUSH-MODE] "
                "FlushMode enum → FlushModeType (jakarta.persistence). "
                "Verify import: jakarta.persistence.FlushModeType"
            )
            flagged += 1
            if dry_run:
                console.dry(f"{file_rel}: would flag FlushMode → FlushModeType")
            else:
                console.warn(f"{file_rel}: FlushMode.X → FlushModeType.X — flagged with TODO")

        new_lines.append(line)

    return "\n".join(new_lines), flagged


def _detect_scrollable_results(content: str, file_rel: str, console, dry_run: bool) -> int:
    """
    Detect ScrollableResults usage and flag .get(int)/.getDate(int) calls
    on that variable specifically. Returns flag count.
    """
    if "ScrollableResults" not in content:
        return 0

    flagged = 0
    # Find the variable name(s) declared as ScrollableResults
    var_names = re.findall(r"ScrollableResults\s+(\w+)\s*=", content)
    if not var_names:
        return 0

    lines = content.split("\n")
    for i, line in enumerate(lines):
        for var in var_names:
            if re.search(rf"\b{var}\s*\.\s*(get|getDate|getInteger|getLong|getString)\s*\(\s*\d+\s*\)", line):
                if "TODO[hibernate-migration]" not in line:
                    flagged += 1
                    if dry_run:
                        console.dry(f"{file_rel}:{i+1}: would flag ScrollableResults indexed get()")
                    else:
                        console.warn(
                            f"{file_rel}:{i+1}: ScrollableResults.get(int)/getDate(int) removed in H7 — "
                            f"use get() returning Object[] and index into the array. Flagged with TODO."
                        )

    return flagged


def apply(module_path: Path, dry_run: bool, console) -> int:
    changed = 0
    candidates = files_containing(
        find_java_files(module_path),
        ".get(", "setString(", "setInteger(", "setLong(", "setBoolean(",
        "setDate(", "setTimestamp(", "setDouble(", "setFloat(",
        "uniqueResult(", ".list(", "org.hibernate.Query;", "@OrderBy",
        "Environment.USE_REFLECTION_OPTIMIZER", "setHibernateFlushMode",
        "FlushMode.", "ScrollableResults",
    )

    for java_file in candidates:
        original = read_file(java_file)
        rel = str(java_file.relative_to(module_path))

        content, mech_changes = _apply_mechanical(original)
        for desc in mech_changes:
            if dry_run:
                console.dry(f"{rel}: would change {desc}")
            else:
                console.change(f"{rel}: {desc}")
            changed += 1

        content, n_flagged = _apply_flags(content, rel, console, dry_run)
        changed += n_flagged

        n_scrollable = _detect_scrollable_results(content, rel, console, dry_run)
        changed += n_scrollable

        if not dry_run and content != original:
            write_file(java_file, content)

    return changed
