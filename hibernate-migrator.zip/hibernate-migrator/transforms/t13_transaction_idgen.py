"""
Transform 13: Transaction interface + custom ID generator changes (H7).

1. Custom Transaction wrapper classes implementing org.hibernate.Transaction:
   - Must add markRollbackOnly() (new method, no default — interface requires it)
   - setTimeout(int) AND setTimeout(Integer) both required (overload, not rename)
   - getTimeout() return type changed int → Integer

2. Custom ID generators extending/implementing TableInstanceHiLoGenerator
   (or similar org.hibernate.id generators):
   - generate() return type changed Serializable → Object
   - configure() deprecated — needs @SuppressWarnings("removal") if still overridden

Both are narrow, structural, lean-prompt cases — no full class needed.
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files, find_java_files as _ffj


# ── Custom Transaction wrapper detection ──────────────────────────────────────

_TODO_TRANSACTION = """\
// TODO[hibernate-migration][TRANSACTION-IFACE] org.hibernate.Transaction interface changed in H7.
// See COPILOT-HANDOFF.md for exact method signature changes needed.
"""

_TODO_ID_GENERATOR = """\
// TODO[hibernate-migration][ID-GENERATOR] Custom ID generator signature changed in H7.
// See COPILOT-HANDOFF.md for exact changes needed.
"""


def _lean_prompt_transaction(class_name: str) -> str:
    return (
        f"The class `{class_name}` implements `org.hibernate.Transaction`. "
        f"In Hibernate 7 the interface changed:\n\n"
        f"1. Add a new method (required, no default implementation):\n"
        f"   public void markRollbackOnly() {{ /* mark transaction for rollback, "
        f"implement based on existing rollback() logic */ }}\n\n"
        f"2. Both overloads are now required:\n"
        f"   public void setTimeout(int seconds) {{ ... }}\n"
        f"   public void setTimeout(Integer seconds) {{ ... }}\n"
        f"   (delegate one to the other, e.g. setTimeout(int) calls setTimeout(Integer.valueOf(...)))\n\n"
        f"3. Change getTimeout() return type from int to Integer:\n"
        f"   public Integer getTimeout() {{ ... }}\n\n"
        f"Apply only these signature changes. Keep all existing logic. "
        f"Output only the modified class."
    )


def _lean_prompt_id_generator(class_name: str) -> str:
    return (
        f"The class `{class_name}` is a custom Hibernate ID generator "
        f"(e.g. extends/implements TableInstanceHiLoGenerator or similar). "
        f"In Hibernate 7:\n\n"
        f"1. Change generate() return type from Serializable to Object:\n"
        f"   public Object generate(SharedSessionContractImplementor session, Object owner) {{ ... }}\n\n"
        f"2. If configure() is overridden, it is deprecated for removal — "
        f"add @SuppressWarnings(\"removal\") above the method, keep the logic as-is.\n\n"
        f"Apply only these signature/annotation changes. Keep all existing logic. "
        f"Output only the modified class."
    )


def collect_transaction_tasks(module_path: Path, dry_run: bool, console) -> list[dict]:
    tasks = []
    for java_file in find_java_files(module_path):
        content = read_file(java_file)
        if "implements Transaction" not in content and "implements org.hibernate.Transaction" not in content:
            continue
        if "TODO[hibernate-migration][TRANSACTION-IFACE]" in content:
            continue

        rel = str(java_file.relative_to(module_path))
        class_match = re.search(r"class\s+(\w+)\s+implements\s+(?:org\.hibernate\.)?Transaction", content)
        class_name = class_match.group(1) if class_match else java_file.stem

        console.warn(f"{rel}: implements Transaction — class '{class_name}' needs interface update")

        lines = content.split("\n")
        new_lines = []
        inserted = False
        for line in lines:
            if not inserted and re.search(r"implements\s+(?:org\.hibernate\.)?Transaction\b", line):
                indent = " " * (len(line) - len(line.lstrip()))
                for tl in _TODO_TRANSACTION.strip().split("\n"):
                    new_lines.append(indent + tl)
                inserted = True
            new_lines.append(line)

        new_content = "\n".join(new_lines)
        if not dry_run and new_content != content:
            write_file(java_file, new_content)

        tasks.append({
            "kind": "TRANSACTION-IFACE",
            "file_rel": rel,
            "line_start": next(
                (i + 1 for i, l in enumerate(lines)
                 if re.search(r"implements\s+(?:org\.hibernate\.)?Transaction\b", l)), 1
            ),
            "description": f"Transaction interface update: {class_name}",
            "prompt": _lean_prompt_transaction(class_name),
            "code_block": "",
        })

    return tasks


def collect_id_generator_tasks(module_path: Path, dry_run: bool, console) -> list[dict]:
    tasks = []
    generator_signals = ["TableInstanceHiLoGenerator", "implements IdentifierGenerator"]

    for java_file in find_java_files(module_path):
        content = read_file(java_file)
        if not any(sig in content for sig in generator_signals):
            continue
        if "TODO[hibernate-migration][ID-GENERATOR]" in content:
            continue

        rel = str(java_file.relative_to(module_path))
        class_match = re.search(r"class\s+(\w+)\s+(?:extends|implements)\s+\w*(?:HiLoGenerator|IdentifierGenerator)", content)
        class_name = class_match.group(1) if class_match else java_file.stem

        console.warn(f"{rel}: custom ID generator — class '{class_name}' needs signature update")

        lines = content.split("\n")
        new_lines = []
        inserted = False
        for line in lines:
            if not inserted and any(sig in line for sig in generator_signals):
                indent = " " * (len(line) - len(line.lstrip()))
                for tl in _TODO_ID_GENERATOR.strip().split("\n"):
                    new_lines.append(indent + tl)
                inserted = True
            new_lines.append(line)

        new_content = "\n".join(new_lines)
        if not dry_run and new_content != content:
            write_file(java_file, new_content)

        tasks.append({
            "kind": "ID-GENERATOR",
            "file_rel": rel,
            "line_start": next(
                (i + 1 for i, l in enumerate(lines) if any(sig in l for sig in generator_signals)), 1
            ),
            "description": f"ID generator signature update: {class_name}",
            "prompt": _lean_prompt_id_generator(class_name),
            "code_block": "",
        })

    return tasks


def apply(module_path: Path, dry_run: bool, console) -> tuple[int, list[dict]]:
    tasks = []
    tasks += collect_transaction_tasks(module_path, dry_run, console)
    tasks += collect_id_generator_tasks(module_path, dry_run, console)
    return len(tasks), tasks
