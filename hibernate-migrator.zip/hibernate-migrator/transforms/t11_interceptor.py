"""
Transform 11: EmptyInterceptor → Interceptor interface (handoff, lean prompts).

EmptyInterceptor was deleted in Hibernate 7. Classes extending it must
switch to implementing org.hibernate.Interceptor directly (which now has
default no-op methods on the interface itself — same effect as EmptyInterceptor
used to provide).

DESIGN NOTE ON PROMPT SIZE:
Earlier transforms (t6, t9) sent the FULL class/method source into the
Copilot prompt. For structural renames like this one, that is unnecessary —
the instruction is fully specified by:
  - the class name
  - which interceptor methods are overridden (we can detect this with regex)
  - the specific signature changes needed

So this transform sends a SHORT, TARGETED prompt listing only:
  - the class name and file
  - the exact overridden methods found (so Copilot knows what to touch)
  - the precise renames/signature changes to apply

Copilot already has the file open in IntelliJ, so it has full context —
we don't need to paste the class into the prompt at all.
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files, files_containing


# Method signature changes EmptyInterceptor → Interceptor in H7
_METHOD_CHANGES = {
    "onSave":     "onPersist — renamed, and id parameter changed from Serializable to Object",
    "onFlushDirty": "id parameter changed from Serializable to Object",
    "onDelete":   "id parameter changed from Serializable to Object; remove any super.onDelete() call",
    "onLoad":     "id parameter changed from Serializable to Object",
    "postFlush":  "Iterator parameter is now generic: Iterator<Object> instead of raw Iterator",
}

_INTERCEPTOR_TODO = """\
// TODO[hibernate-migration][INTERCEPTOR] EmptyInterceptor removed in Hibernate 7.
// See COPILOT-HANDOFF.md for exact migration steps for this class.
"""


def _detect_overridden_methods(content: str) -> list[str]:
    """Return list of EmptyInterceptor methods overridden in this class."""
    found = []
    for method in _METHOD_CHANGES:
        if re.search(rf"\b{method}\s*\(", content):
            found.append(method)
    return found


def _has_super_call(content: str) -> bool:
    return bool(re.search(r"super\s*\.\s*on\w+\s*\(", content))


def _has_serializable_field(content: str) -> bool:
    return "serialVersionUID" in content


def _lean_prompt(class_name: str, overridden_methods: list[str],
                  has_super_call: bool, has_serial: bool) -> str:
    """
    Build a short, targeted prompt. No class source pasted —
    Copilot has the file open and can see it directly.
    """
    lines = [
        f"This class `{class_name}` extends `EmptyInterceptor`, which is removed in Hibernate 7.",
        f"Migrate it to `implements Interceptor` instead.",
        "",
        "Apply exactly these changes:",
        "1. Change `extends EmptyInterceptor` to `implements Interceptor`",
        "2. Fix the import: `org.hibernate.EmptyInterceptor` → `org.hibernate.Interceptor`",
    ]

    step = 3
    for method in overridden_methods:
        lines.append(f"{step}. In `{method}()`: {_METHOD_CHANGES[method]}")
        step += 1

    if has_super_call:
        lines.append(
            f"{step}. Remove any `super.onXxx()` calls — `Interceptor` is an interface "
            f"with default no-op methods, calling super on a default method is unnecessary "
            f"and may not compile depending on the override structure"
        )
        step += 1

    if has_serial:
        lines.append(
            f"{step}. Remove `serialVersionUID` field — the class is no longer required "
            f"to implement `Serializable` (Interceptor does not extend Serializable)"
        )
        step += 1

    lines.append("")
    lines.append("Do not change any other logic. Output only the modified class.")

    return "\n".join(lines)


def collect_interceptor_tasks(module_path: Path, dry_run: bool, console) -> list[dict]:
    """
    Find classes extending EmptyInterceptor, insert inline TODO,
    return lean handoff tasks (no full class source in the prompt).
    """
    tasks = []
    for java_file in find_java_files(module_path):
        content = read_file(java_file)
        if "EmptyInterceptor" not in content or "extends EmptyInterceptor" not in content:
            continue
        if "TODO[hibernate-migration][INTERCEPTOR]" in content:
            continue

        rel = str(java_file.relative_to(module_path))
        class_match = re.search(r"class\s+(\w+)\s+extends\s+EmptyInterceptor", content)
        class_name = class_match.group(1) if class_match else java_file.stem

        overridden = _detect_overridden_methods(content)
        has_super = _has_super_call(content)
        has_serial = _has_serializable_field(content)

        console.warn(
            f"{rel}: extends EmptyInterceptor — class '{class_name}', "
            f"{len(overridden)} overridden method(s): {', '.join(overridden) or 'none detected'}"
        )

        # Insert inline TODO at class declaration line
        lines = content.split("\n")
        new_lines = []
        inserted = False
        for line in lines:
            if not inserted and "extends EmptyInterceptor" in line:
                indent = " " * (len(line) - len(line.lstrip()))
                for tl in _INTERCEPTOR_TODO.strip().split("\n"):
                    new_lines.append(indent + tl)
                inserted = True
            new_lines.append(line)

        new_content = "\n".join(new_lines)
        if not dry_run and new_content != content:
            write_file(java_file, new_content)

        prompt = _lean_prompt(class_name, overridden, has_super, has_serial)

        tasks.append({
            "kind": "INTERCEPTOR",
            "file_rel": rel,
            "line_start": next(
                (i + 1 for i, l in enumerate(lines) if "extends EmptyInterceptor" in l), 1
            ),
            "description": f"EmptyInterceptor → Interceptor: {class_name}",
            "prompt": prompt,
            "code_block": "",  # deliberately empty — file is already open in IntelliJ
        })

    return tasks


def apply(module_path: Path, dry_run: bool, console) -> tuple[int, list[dict]]:
    tasks = collect_interceptor_tasks(module_path, dry_run, console)
    return len(tasks), tasks
