"""
Transform 9: Spring-orm → pure Hibernate migration (handoff only).

Detects usage of:
  - LocalSessionFactoryBean
  - HibernateTransactionManager
  - HibernateTemplate / HibernateDaoSupport
  - @Transactional methods

For each detected pattern:
  - Inserts a precise inline TODO comment showing the exact replacement
  - Adds a task to COPILOT-HANDOFF.md with the full method/class and prompt

Spring DI (@Autowired, @Component, @Bean) is deliberately left untouched —
only the Hibernate-specific Spring-orm layer is replaced.

NOT automated because:
  - @Transactional methods need manual transaction blocks wrapped around body
  - LocalSessionFactoryBean wiring is app-specific
  - Nested @Transactional propagation needs case-by-case judgement
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files, files_containing


# ── Detection patterns ────────────────────────────────────────────────────────

SPRING_ORM_IMPORTS = [
    "org.springframework.orm.hibernate5",
    "org.springframework.orm.hibernate6",
    "org.springframework.transaction.annotation.Transactional",
    "HibernateTemplate",
    "HibernateDaoSupport",
    "HibernateTransactionManager",
    "LocalSessionFactoryBean",
]

TRANSACTIONAL_PATTERN = re.compile(
    r'@Transactional(\s*\([^)]*\))?\s*\n\s*(public|private|protected)',
    re.MULTILINE,
)


# ── Inline TODO templates ─────────────────────────────────────────────────────

_TODO_LOCAL_SESSION_FACTORY = """\
// TODO[hibernate-migration][SPRING-ORM] Replace LocalSessionFactoryBean.
// Instead, build SessionFactory manually (consistent with other modules):
//
//   Configuration config = new Configuration();
//   config.setProperty("hibernate.dialect", "org.hibernate.dialect.OracleDialect");
//   config.setProperty("hibernate.connection.provider_class",
//       "org.hibernate.hikaricp.internal.HikariCPConnectionProvider");
//   config.setProperty("hibernate.hikari.connectionInitSql", YourClass.generateInitSql());
//   config.addAnnotatedClass(MyEntity.class); // repeat for each entity
//   SessionFactory sessionFactory = config.buildSessionFactory();
//
// Expose sessionFactory as a @Bean if other Spring beans need it.
// Remove spring-orm dependency from build.gradle once done.
"""

_TODO_TRANSACTION_MANAGER = """\
// TODO[hibernate-migration][SPRING-ORM] Replace HibernateTransactionManager.
// Remove this bean — transaction management will be manual per method.
// Each @Transactional method gets replaced with:
//
//   Transaction tx = session.beginTransaction();
//   try {
//       // method body here
//       tx.commit();
//   } catch (Exception e) {
//       tx.rollback();
//       throw e;
//   }
//
// See COPILOT-HANDOFF.md for per-method migration tasks.
"""

_TODO_HIBERNATE_TEMPLATE = """\
// TODO[hibernate-migration][SPRING-ORM] Replace HibernateTemplate / HibernateDaoSupport.
// Inject SessionFactory directly instead:
//
//   @Autowired  // keep Spring DI
//   private SessionFactory sessionFactory;
//
//   // Then use sessions directly:
//   try (Session session = sessionFactory.openSession()) {
//       // your query here
//   }
//
// See COPILOT-HANDOFF.md for full class migration task.
"""

_TODO_TRANSACTIONAL = """\
// TODO[hibernate-migration][SPRING-ORM] Replace @Transactional with manual transaction.
// Remove @Transactional annotation and wrap method body:
//
//   Transaction tx = session.beginTransaction();
//   try {
//       // existing method body
//       tx.commit();
//   } catch (Exception e) {
//       if (tx != null) tx.rollback();
//       throw e;
//   }
"""


# ── Prompt builders ───────────────────────────────────────────────────────────

def _prompt_local_session_factory(class_source: str) -> str:
    return (
        "Migrate this Spring LocalSessionFactoryBean configuration class to "
        "pure Hibernate 7 without Spring-orm.\n\n"
        "Context:\n"
        "- We use pure Hibernate native API (Session/SessionFactory) in all other modules\n"
        "- We use Spring DI (@Autowired, @Bean, @Component) — keep that\n"
        "- We use HikariCP for connection pooling (hibernate-hikaricp:7.4.2.Final)\n"
        "- Database is Oracle\n"
        "- Entities are registered via config.addAnnotatedClass() — no package scanning\n"
        "- SessionFactory init SQL is provided by a generateInitSql() method\n\n"
        "Rules:\n"
        "- Replace LocalSessionFactoryBean with a @Bean method that returns SessionFactory\n"
        "- Build SessionFactory using new Configuration() programmatically\n"
        "- Wire HikariCP via hibernate.hikari.* properties\n"
        "- Call generateInitSql() for connectionInitSql — preserve the method call\n"
        "- Keep all @Bean, @Configuration, @Autowired annotations\n"
        "- Remove all spring-orm imports\n"
        "- Output ONLY the migrated class — no explanation, no markdown fences\n\n"
        "Class to migrate:\n"
        "```java\n"
        f"{class_source}\n"
        "```"
    )


def _prompt_transaction_manager(class_source: str) -> str:
    return (
        "Remove HibernateTransactionManager from this Spring configuration class.\n\n"
        "Context:\n"
        "- Transactions will be managed manually per method (beginTransaction/commit/rollback)\n"
        "- Keep Spring DI (@Bean, @Configuration, @Autowired)\n"
        "- Remove the HibernateTransactionManager @Bean method entirely\n"
        "- Remove spring-orm imports related to transaction management\n\n"
        "Rules:\n"
        "- Only remove the HibernateTransactionManager bean and its imports\n"
        "- Do not change other beans in the class\n"
        "- Output ONLY the migrated class — no explanation, no markdown fences\n\n"
        "Class to migrate:\n"
        "```java\n"
        f"{class_source}\n"
        "```"
    )


def _prompt_hibernate_template(class_source: str) -> str:
    return (
        "Migrate this class from HibernateTemplate/HibernateDaoSupport to "
        "pure Hibernate 7 Session API.\n\n"
        "Context:\n"
        "- Pure Hibernate native API — Session/SessionFactory only\n"
        "- Spring DI is kept (@Autowired, @Component, @Repository etc)\n"
        "- Database is Oracle, Hibernate 7.4.2.Final\n\n"
        "Migration rules:\n"
        "- Replace 'extends HibernateDaoSupport' with a plain class\n"
        "- Replace HibernateTemplate field with @Autowired SessionFactory\n"
        "- Replace getHibernateTemplate().xxx() calls:\n"
        "    .get(Class, id)      → session.get(Class, id)\n"
        "    .save(obj)           → session.persist(obj)\n"
        "    .update(obj)         → session.merge(obj)\n"
        "    .delete(obj)         → session.remove(obj)\n"
        "    .find(hql)           → session.createQuery(hql).getResultList()\n"
        "    .execute(callback)   → session.doWork()\n"
        "- Wrap each DAO method with: try (Session session = sessionFactory.openSession())\n"
        "- Keep all Spring DI annotations\n"
        "- Remove all spring-orm imports\n"
        "- Output ONLY the migrated class — no explanation, no markdown fences\n\n"
        "Class to migrate:\n"
        "```java\n"
        f"{class_source}\n"
        "```"
    )


def _prompt_transactional_method(method_text: str, propagation: str | None) -> str:
    propagation_note = ""
    if propagation:
        propagation_note = (
            f"\nNote: This method uses @Transactional({propagation}). "
            f"Handle propagation manually:\n"
            f"- REQUIRES_NEW: always open a new session and transaction\n"
            f"- NESTED: use a JDBC savepoint if supported, otherwise treat as REQUIRED\n"
            f"- MANDATORY: assert an active session exists before proceeding\n"
        )

    return (
        "Migrate this @Transactional method to use manual Hibernate transaction management.\n\n"
        "Context:\n"
        "- Pure Hibernate native API — Session/SessionFactory\n"
        "- SessionFactory is available as a field (already @Autowired)\n"
        "- Spring DI annotations on the class stay — only @Transactional is removed\n"
        f"{propagation_note}\n"
        "Rules:\n"
        "- Remove the @Transactional annotation\n"
        "- Wrap the method body in:\n"
        "    Transaction tx = null;\n"
        "    try (Session session = sessionFactory.openSession()) {\n"
        "        tx = session.beginTransaction();\n"
        "        // existing body here\n"
        "        tx.commit();\n"
        "    } catch (Exception e) {\n"
        "        if (tx != null) tx.rollback();\n"
        "        throw e;\n"
        "    }\n"
        "- If the method already has a session parameter, use that instead of opening a new one\n"
        "- Preserve method signature, return type, and throws clause exactly\n"
        "- Output ONLY the migrated method — no explanation, no markdown fences\n\n"
        "Method to migrate:\n"
        "```java\n"
        f"{method_text}\n"
        "```"
    )


# ── File-level detection ──────────────────────────────────────────────────────

def _detect_spring_orm_kind(content: str) -> set[str]:
    """Return set of spring-orm kinds found in this file."""
    kinds = set()
    if "LocalSessionFactoryBean" in content:
        kinds.add("LOCAL_SESSION_FACTORY")
    if "HibernateTransactionManager" in content:
        kinds.add("TRANSACTION_MANAGER")
    if "HibernateTemplate" in content or "HibernateDaoSupport" in content:
        kinds.add("HIBERNATE_TEMPLATE")
    if "@Transactional" in content:
        kinds.add("TRANSACTIONAL")
    return kinds


def _extract_methods_with_transactional(content: str) -> list[tuple[int, int, str, str | None]]:
    """
    Extract (start_line_0, end_line_0, method_text, propagation) for each
    @Transactional method. propagation is the value inside parens if present.
    """
    results = []
    lines = content.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]
        # Look for @Transactional
        if re.search(r'@Transactional', line):
            # Extract propagation if present
            prop_match = re.search(r'propagation\s*=\s*Propagation\.(\w+)', line)
            propagation = prop_match.group(1) if prop_match else None

            # Find the method declaration on the next non-blank line
            j = i + 1
            while j < len(lines) and not re.search(
                r'\b(public|private|protected)\b.*\(', lines[j]
            ):
                j += 1

            if j >= len(lines):
                i += 1
                continue

            # Collect method body by brace matching
            method_start = i  # include @Transactional line
            depth = 0
            k = j
            while k < len(lines):
                depth += lines[k].count("{") - lines[k].count("}")
                k += 1
                if depth > 0:
                    break
            # Now collect until depth returns to 0
            while k < len(lines) and depth > 0:
                depth += lines[k].count("{") - lines[k].count("}")
                k += 1

            method_text = "\n".join(lines[method_start:k])
            results.append((method_start, k, method_text, propagation))
            i = k
        else:
            i += 1

    return results


# ── TODO injection ────────────────────────────────────────────────────────────

def _inject_todos(content: str, kinds: set[str]) -> tuple[str, int]:
    """Insert inline TODO comments for each detected spring-orm pattern."""
    lines = content.split("\n")
    new_lines = []
    changes = 0

    for line in lines:
        # LocalSessionFactoryBean
        if "LOCAL_SESSION_FACTORY" in kinds and "LocalSessionFactoryBean" in line \
                and "TODO[hibernate-migration]" not in line:
            indent = " " * (len(line) - len(line.lstrip()))
            for tl in _TODO_LOCAL_SESSION_FACTORY.strip().split("\n"):
                new_lines.append(indent + tl)
            changes += 1

        # HibernateTransactionManager
        if "TRANSACTION_MANAGER" in kinds and "HibernateTransactionManager" in line \
                and "TODO[hibernate-migration]" not in line:
            indent = " " * (len(line) - len(line.lstrip()))
            for tl in _TODO_TRANSACTION_MANAGER.strip().split("\n"):
                new_lines.append(indent + tl)
            changes += 1

        # HibernateTemplate / HibernateDaoSupport
        if "HIBERNATE_TEMPLATE" in kinds and (
            "HibernateTemplate" in line or "HibernateDaoSupport" in line
        ) and "TODO[hibernate-migration]" not in line:
            indent = " " * (len(line) - len(line.lstrip()))
            for tl in _TODO_HIBERNATE_TEMPLATE.strip().split("\n"):
                new_lines.append(indent + tl)
            changes += 1

        # @Transactional
        if "TRANSACTIONAL" in kinds and re.search(r'^\s*@Transactional', line) \
                and "TODO[hibernate-migration]" not in line:
            indent = " " * (len(line) - len(line.lstrip()))
            for tl in _TODO_TRANSACTIONAL.strip().split("\n"):
                new_lines.append(indent + tl)
            changes += 1

        new_lines.append(line)

    return "\n".join(new_lines), changes


# ── Gradle: remove spring-orm dependency ─────────────────────────────────────

def _flag_spring_orm_gradle(module_path: Path, dry_run: bool, console) -> int:
    """Flag spring-orm in build.gradle with a removal TODO."""
    changed = 0
    for gradle_file in [module_path / "build.gradle", module_path / "build.gradle.kts"]:
        if not gradle_file.exists():
            continue
        original = read_file(gradle_file)
        content = original

        def _flag_line(m):
            return (
                f"// TODO[hibernate-migration][SPRING-ORM] Remove after migration complete:\n"
                f"// {m.group(0)}"
            )

        new_content = re.sub(
            r".*spring-orm.*",
            _flag_line,
            content,
        )
        if new_content != content:
            rel = gradle_file.relative_to(module_path)
            if dry_run:
                console.dry(f"{rel}: would flag spring-orm dependency for removal")
            else:
                console.change(f"{rel}: flagged spring-orm dependency for removal after migration")
            changed += 1
            if not dry_run:
                write_file(gradle_file, new_content)

    return changed


# ── Main apply ────────────────────────────────────────────────────────────────

def apply(module_path: Path, dry_run: bool, console) -> tuple[int, list[dict]]:
    """
    Scan for Spring-orm usage, inject TODOs, return handoff tasks.
    Returns (change_count, handoff_tasks).
    """
    changed = 0
    handoff_tasks = []

    candidates = files_containing(
        find_java_files(module_path),
        *SPRING_ORM_IMPORTS,
    )

    if not candidates:
        return 0, []

    console.info(f"  Spring-orm detected in {len(candidates)} file(s)")

    # Flag spring-orm in build.gradle
    changed += _flag_spring_orm_gradle(module_path, dry_run, console)

    for java_file in candidates:
        original = read_file(java_file)
        rel = str(java_file.relative_to(module_path))
        kinds = _detect_spring_orm_kind(original)

        if not kinds:
            continue

        console.warn(f"  {rel}: Spring-orm detected — {', '.join(sorted(kinds))}")

        # Inject inline TODOs
        content, n = _inject_todos(original, kinds)
        changed += n
        if not dry_run and content != original:
            write_file(java_file, content)

        # Build handoff tasks

        # LocalSessionFactoryBean — full class task
        if "LOCAL_SESSION_FACTORY" in kinds:
            handoff_tasks.append({
                "kind": "SPRING-ORM",
                "file_rel": rel,
                "line_start": 1,
                "description": "Replace LocalSessionFactoryBean with manual SessionFactory config",
                "prompt": _prompt_local_session_factory(original),
                "code_block": original,
            })
            console.info(f"    [Handoff] LocalSessionFactoryBean → manual Configuration")

        # HibernateTransactionManager — full class task
        if "TRANSACTION_MANAGER" in kinds:
            handoff_tasks.append({
                "kind": "SPRING-ORM",
                "file_rel": rel,
                "line_start": 1,
                "description": "Remove HibernateTransactionManager bean",
                "prompt": _prompt_transaction_manager(original),
                "code_block": original,
            })
            console.info(f"    [Handoff] HibernateTransactionManager → remove")

        # HibernateTemplate/HibernateDaoSupport — full class task
        if "HIBERNATE_TEMPLATE" in kinds:
            handoff_tasks.append({
                "kind": "SPRING-ORM",
                "file_rel": rel,
                "line_start": 1,
                "description": "Replace HibernateTemplate/HibernateDaoSupport with Session API",
                "prompt": _prompt_hibernate_template(original),
                "code_block": original,
            })
            console.info(f"    [Handoff] HibernateTemplate → direct Session usage")

        # @Transactional — one task per method
        if "TRANSACTIONAL" in kinds:
            methods = _extract_methods_with_transactional(original)
            for start, _end, method_text, propagation in methods:
                handoff_tasks.append({
                    "kind": "SPRING-ORM",
                    "file_rel": rel,
                    "line_start": start + 1,
                    "description": (
                        f"@Transactional method at line {start + 1}"
                        + (f" [propagation={propagation}]" if propagation else "")
                    ),
                    "prompt": _prompt_transactional_method(method_text, propagation),
                    "code_block": method_text,
                })
                console.info(
                    f"    [Handoff] @Transactional method at line {start + 1}"
                    + (f" [{propagation}]" if propagation else "")
                )

    return changed, handoff_tasks
