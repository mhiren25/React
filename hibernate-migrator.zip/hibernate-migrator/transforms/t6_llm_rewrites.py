"""
Transform 6: IntelliJ Copilot Chat handoff.

For the two transforms that regex/AST cannot handle safely:
  1. Hibernate 5 Criteria API → CriteriaBuilder
  2. UserType interface migration to H7 signatures

Instead of calling an LLM directly, this transform:
  - Inserts TODO[hibernate-migration] comments inline in affected Java files
  - Generates a single COPILOT-HANDOFF.md file in the module root

The developer then opens COPILOT-HANDOFF.md in IntelliJ and works through
each task using the GitHub Copilot Chat panel at their own pace.
"""

from pathlib import Path
from llm.handoff import generate


def apply(module_path: Path, dry_run: bool, console, skip_llm: bool = False) -> int:
    """
    Scan for Criteria and UserType blocks, write inline TODOs and handoff file.
    Returns number of tasks generated.
    """
    if skip_llm:
        console.skip("LLM handoff skipped (--skip-llm flag) — Criteria/UserType blocks not flagged")
        return 0

    count, handoff_path = generate(module_path, dry_run, console)
    return count
