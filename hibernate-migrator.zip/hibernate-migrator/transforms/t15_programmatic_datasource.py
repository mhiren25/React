"""
Transform 15: Programmatic Configuration.setProperty() → HikariCP DataSource.

Confirmed pattern: credentials and connection settings are passed
programmatically via Configuration.setProperty(Environment.X, ...) in Java,
NOT via a properties file. This is structurally different from what T7
handles (which covers .properties/.cfg.xml files and Gradle deps only).

Why this needs a handoff task rather than a mechanical rewrite:
  - The fix isn't a string substitution — it's a structural change from
    "set string properties on Configuration" to "build a HikariConfig +
    DataSource object and pass it via ServiceRegistry"
  - Property VALUES (URL, username, password source) are business logic
    the agent cannot safely infer or guess at
  - If a custom ConnectionCustomizer/DbUtils login class is also detected
    in the same file (see T7's AbstractConnectionCustomizer detection),
    this task explicitly links the two so the developer does both pieces
    of the migration together, not as separate disconnected steps

This transform does NOT touch the file — it only detects and adds a
handoff task. The actual code change is structural enough that auto-edit
risk outweighs the benefit, unlike the safe mechanical transforms.
"""

import re
from pathlib import Path
from utils.files import read_file, find_java_files, files_containing


# Programmatic c3p0/connection Environment keys that signal this pattern
_ENVIRONMENT_KEYS = [
    "Environment.CONNECTION_PROVIDER",
    "Environment.URL",
    "Environment.USER",
    "Environment.PASS",
    "Environment.DRIVER",
    "hibernate.c3p0.",
    "hibernate.connection.provider_class",
    "C3P0ConnectionProvider",
]

_TODO = """\
// TODO[hibernate-migration][PROGRAMMATIC-DATASOURCE] Programmatic c3p0 Configuration detected.
// See COPILOT-HANDOFF.md — replace setProperty(Environment.X, ...) calls with
// a HikariConfig + DataSource built and passed via ServiceRegistry.
"""


def _detect_setproperty_keys(content: str) -> list[str]:
    """Return which Environment/c3p0 keys are set programmatically in this file."""
    found = []
    for key in _ENVIRONMENT_KEYS:
        if key in content:
            found.append(key)
    return found


def _has_custom_customizer_nearby(content: str) -> str | None:
    """
    Check if this file also references a custom connection customizer class
    (e.g. DbLoginConnectionCustomizer) so the handoff task can link both
    pieces of the migration together.
    """
    match = re.search(r'connectionCustomizerClassName["\'\s,]*[:=]?\s*["\']([\w.]+)["\']', content)
    if match:
        return match.group(1)
    # Also check for a direct class reference without the property string form
    match2 = re.search(r'(\w*Customizer)\.class', content)
    if match2:
        return match2.group(1)
    return None


def _lean_prompt(file_rel: str, found_keys: list[str], customizer_class: str | None) -> str:
    customizer_note = ""
    if customizer_class:
        customizer_note = (
            f"\nThis file also references a custom connection customizer "
            f"(`{customizer_class}`). If that class extends "
            f"AbstractConnectionCustomizer and calls a DB login routine "
            f"(e.g. DbUtils.login()), migrate both together: build a custom "
            f"HikariDataSource subclass that runs the same login logic in an "
            f"overridden getConnection() method, instead of relying on a "
            f"separate customizer class.\n"
        )

    keys_list = "\n".join(f"  - {k}" for k in found_keys)

    return (
        f"This file builds a Hibernate SessionFactory using programmatic "
        f"`Configuration.setProperty()` calls for c3p0/connection settings. "
        f"Detected keys in this file:\n{keys_list}\n"
        f"{customizer_note}\n"
        f"Migrate this to HikariCP using the DataSource-object approach "
        f"(not property-string based), because credentials and pool config "
        f"need to move from `Configuration.setProperty()` calls to a "
        f"`HikariConfig` + `DataSource` object:\n\n"
        f"1. Remove all `Environment.CONNECTION_PROVIDER`, `Environment.URL`, "
        f"`Environment.USER`, `Environment.PASS`, `Environment.DRIVER`, and "
        f"any `hibernate.c3p0.*` setProperty() calls\n"
        f"2. Build a `HikariConfig` object instead, using the same URL/username/"
        f"password/driver values that were previously passed as properties:\n"
        f"   HikariConfig hikariConfig = new HikariConfig();\n"
        f"   hikariConfig.setJdbcUrl(...);     // same value as Environment.URL\n"
        f"   hikariConfig.setUsername(...);    // same value as Environment.USER\n"
        f"   hikariConfig.setPassword(...);    // same value as Environment.PASS\n"
        f"   hikariConfig.setDriverClassName(...); // same value as Environment.DRIVER\n"
        f"   hikariConfig.setMaximumPoolSize(10);\n"
        f"   hikariConfig.setMinimumIdle(2);\n"
        f"   hikariConfig.setConnectionTimeout(30_000);\n"
        f"3. Build the DataSource (use the custom subclass if a connection "
        f"customizer was detected, otherwise plain HikariDataSource):\n"
        f"   DataSource dataSource = new HikariDataSource(hikariConfig);\n"
        f"4. Pass the DataSource object via ServiceRegistry, not Configuration.setProperty():\n"
        f"   ServiceRegistry registry = new StandardServiceRegistryBuilder()\n"
        f"       .applySetting(Environment.DATASOURCE, dataSource)\n"
        f"       .build();\n"
        f"   SessionFactory sessionFactory = config.buildSessionFactory(registry);\n\n"
        f"Keep all other Configuration calls (addAnnotatedClass, dialect, etc) unchanged. "
        f"Output only the modified method/class section that builds the SessionFactory."
    )


def collect_tasks(module_path: Path, dry_run: bool, console) -> list[dict]:
    tasks = []
    candidates = files_containing(find_java_files(module_path), *_ENVIRONMENT_KEYS)

    for java_file in candidates:
        content = read_file(java_file)
        found_keys = _detect_setproperty_keys(content)
        if not found_keys:
            continue

        rel = str(java_file.relative_to(module_path))
        customizer_class = _has_custom_customizer_nearby(content)

        console.warn(
            f"{rel}: programmatic c3p0/connection Configuration detected "
            f"({len(found_keys)} key(s)" +
            (f", linked customizer: {customizer_class}" if customizer_class else "") +
            ")"
        )

        # Find the line to anchor the TODO at — first setProperty call matching our keys
        lines = content.split("\n")
        anchor_line = 1
        for i, line in enumerate(lines):
            if any(k in line for k in found_keys):
                anchor_line = i + 1
                break

        tasks.append({
            "kind": "PROGRAMMATIC-DATASOURCE",
            "file_rel": rel,
            "line_start": anchor_line,
            "description": (
                f"Programmatic c3p0 Configuration → HikariCP DataSource"
                + (f" (linked: {customizer_class})" if customizer_class else "")
            ),
            "prompt": _lean_prompt(rel, found_keys, customizer_class),
            "code_block": "",  # lean — file is open in IntelliJ, no need to duplicate
        })

    return tasks


def apply(module_path: Path, dry_run: bool, console) -> tuple[int, list[dict]]:
    """
    Detection-only transform — does not edit files directly (the change is
    too structural to auto-rewrite safely). Inserts a TODO comment as a
    pointer, and returns handoff tasks for COPILOT-HANDOFF.md.
    """
    from utils.files import write_file

    tasks = collect_tasks(module_path, dry_run, console)

    # Insert inline TODO pointer in each affected file (does not rewrite logic)
    for task in tasks:
        java_file = module_path / task["file_rel"]
        content = read_file(java_file)
        if "TODO[hibernate-migration][PROGRAMMATIC-DATASOURCE]" in content:
            continue

        lines = content.split("\n")
        target_line_idx = task["line_start"] - 1
        if 0 <= target_line_idx < len(lines):
            indent = " " * (len(lines[target_line_idx]) - len(lines[target_line_idx].lstrip()))
            todo_lines = [indent + l for l in _TODO.strip().split("\n")]
            lines = lines[:target_line_idx] + todo_lines + lines[target_line_idx:]
            new_content = "\n".join(lines)
            if not dry_run:
                write_file(java_file, new_content)

    return len(tasks), tasks
