"""
Transform 14: javax.persistence → jakarta.persistence namespace migration.

Confirmed relevant across modules (not just one) per real H7 migration findings.
Hibernate 7 only ships jakarta.persistence — javax.persistence is gone entirely.

Covers:
  1. import javax.persistence.X            → import jakarta.persistence.X
  2. import javax.persistence.X.Y           → import jakarta.persistence.X.Y  (nested/static)
  3. @javax.persistence.Transient            → @jakarta.persistence.Transient (fully-qualified annotation use)
  4. javax.persistence.SomeClass.CONSTANT    → jakarta.persistence.SomeClass.CONSTANT (fully-qualified static ref)
  5. import javax.transaction.Synchronization → import jakarta.transaction.Synchronization
  6. Gradle: hibernate-jpa / javax.persistence-api style deps → jakarta.persistence:jakarta.persistence-api

This is a pure string substitution — javax.persistence.* and jakarta.persistence.*
are drop-in replacements at the source level (same annotation names, same semantics
for the JPA 2.x → JPA 3.x core annotations used here: @Entity, @Table, @Column, @Id,
@Transient, @ManyToOne, etc). No behavioural review needed — this is the single
safest, highest-confidence transform in the whole pipeline.
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files, files_containing


# ── Core namespace swaps ───────────────────────────────────────────────────────

_NAMESPACE_SWAPS = [
    # import javax.persistence.X  (covers single class and wildcard imports)
    (re.compile(r"\bimport\s+javax\.persistence\."), "import jakarta.persistence."),
    # fully-qualified annotation usage: @javax.persistence.Transient
    (re.compile(r"@javax\.persistence\."), "@jakarta.persistence."),
    # fully-qualified static/class reference: javax.persistence.SomeClass.X
    # (not preceded by 'import ' or '@' — those are handled above; this catches
    #  bare references like javax.persistence.criteria.JoinType.LEFT)
    (re.compile(r"(?<!import )(?<!@)\bjavax\.persistence\."), "jakarta.persistence."),
    # javax.transaction.Synchronization (JTA-style transaction sync — separate namespace)
    (re.compile(r"\bimport\s+javax\.transaction\.Synchronization\b"), "import jakarta.transaction.Synchronization"),
    (re.compile(r"(?<!import )\bjavax\.transaction\.Synchronization\b"), "jakarta.transaction.Synchronization"),
]


def _transform_file(content: str) -> tuple[str, list[str]]:
    """Apply all namespace swaps. Returns (new_content, change_descriptions)."""
    changes = []

    for pattern, replacement in _NAMESPACE_SWAPS:
        matches = pattern.findall(content)
        if matches:
            new_content = pattern.sub(replacement, content)
            if new_content != content:
                count = len(pattern.findall(content))
                # Describe what matched, in human-readable form
                sample = pattern.pattern.replace(r"\b", "").replace(r"\.", ".").replace(r"(?<!import )", "").replace(r"(?<!@)", "")
                changes.append(f"{sample} → {replacement} [{count}x]")
                content = new_content

    return content, changes


# ── Gradle dependency swap ─────────────────────────────────────────────────────

_GRADLE_PATTERNS = [
    # hibernate-jpa bridge artifacts (various group/artifact naming conventions seen historically)
    (
        r"org\.hibernate\.javax\.persistence:hibernate-jpa-[\d.]+-api:[^\s'\"]+",
        'jakarta.persistence:jakarta.persistence-api:3.1.0',
    ),
    (
        r"javax\.persistence:javax\.persistence-api:[^\s'\"]+",
        'jakarta.persistence:jakarta.persistence-api:3.1.0',
    ),
    (
        r"javax\.persistence:persistence-api:[^\s'\"]+",
        'jakarta.persistence:jakarta.persistence-api:3.1.0',
    ),
    # javax.transaction-api → jakarta equivalent
    (
        r"javax\.transaction:javax\.transaction-api:[^\s'\"]+",
        'jakarta.transaction:jakarta.transaction-api:2.0.1',
    ),
]


def _apply_gradle(module_path: Path, dry_run: bool, console) -> int:
    changed = 0
    for gradle_file in [module_path / "build.gradle", module_path / "build.gradle.kts"]:
        if not gradle_file.exists():
            continue
        original = read_file(gradle_file)
        content = original

        for pattern, replacement in _GRADLE_PATTERNS:
            new_content = re.sub(pattern, replacement, content)
            if new_content != content:
                for m in re.findall(pattern, content):
                    if dry_run:
                        console.dry(f"build.gradle: would replace '{m}' → '{replacement}'")
                    else:
                        console.change(f"build.gradle: '{m}' → '{replacement}'")
                    changed += 1
                content = new_content

        if not dry_run and content != original:
            write_file(gradle_file, content)

    return changed


# ── Main apply ────────────────────────────────────────────────────────────────

def apply(module_path: Path, dry_run: bool, console) -> int:
    changed = 0

    # Gradle dependency swap first
    changed += _apply_gradle(module_path, dry_run, console)

    # Java source files
    candidates = files_containing(
        find_java_files(module_path),
        "javax.persistence", "javax.transaction.Synchronization",
    )

    for java_file in candidates:
        original = read_file(java_file)
        content, changes = _transform_file(original)
        rel = java_file.relative_to(module_path)

        for desc in changes:
            if dry_run:
                console.dry(f"{rel}: would change {desc}")
            else:
                console.change(f"{rel}: {desc}")
            changed += 1

        if not dry_run and content != original:
            write_file(java_file, content)

    return changed
