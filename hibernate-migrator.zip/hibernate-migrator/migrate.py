#!/usr/bin/env python3
"""
Hibernate 5.5 → 7.4 Migration Agent
Usage: python migrate.py --module /path/to/your/module
"""

import argparse
import sys
from pathlib import Path

from agent.pipeline import MigrationPipeline
from utils.console import Console


def parse_args():
    parser = argparse.ArgumentParser(
        description="Hibernate 5.5 → 7.4 automated migration agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python migrate.py --module /workspace/myrepo/trade-module
  python migrate.py --module /workspace/myrepo/core-data --dry-run
  python migrate.py --module /workspace/myrepo/order-mgmt --skip-compile
        """
    )
    parser.add_argument(
        "--module",
        required=True,
        help="Absolute path to the module root (must contain build.gradle and src/)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Analyse and print what would change — do not modify any files"
    )
    parser.add_argument(
        "--skip-compile",
        action="store_true",
        help="Skip the Gradle compileJava check after migration"
    )
    parser.add_argument(
        "--skip-git",
        action="store_true",
        help="Skip the git commit after successful migration"
    )
    parser.add_argument(
        "--skip-llm",
        action="store_true",
        help="Skip Copilot handoff generation (Criteria/UserType blocks not flagged)"
    )
    return parser.parse_args()


def main():
    args = parse_args()
    module_path = Path(args.module).resolve() if args.module else None

    console = Console()
    console.header("Hibernate 5.5 → 7.4 Migration Agent")

    if not args.module:
        console.error("--module is required")
        sys.exit(1)

    console.info(f"Module : {module_path}")
    console.info(f"Dry run: {args.dry_run}")
    console.info(f"Handoff: {'disabled' if args.skip_llm else 'COPILOT-HANDOFF.md (IntelliJ Copilot Chat)'}")
    console.separator()

    # Validate module path
    if not module_path.exists():
        console.error(f"Module path does not exist: {module_path}")
        sys.exit(1)
    if not (module_path / "build.gradle").exists():
        console.error(f"No build.gradle found in: {module_path}")
        sys.exit(1)
    if not (module_path / "src").exists():
        console.error(f"No src/ directory found in: {module_path}")
        sys.exit(1)

    pipeline = MigrationPipeline(
        module_path=module_path,
        dry_run=args.dry_run,
        skip_compile=args.skip_compile,
        skip_git=args.skip_git,
        skip_llm=args.skip_llm,
        console=console,
    )

    success = pipeline.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
