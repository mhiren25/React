"""Git operations for the migration agent."""

import subprocess
from pathlib import Path


def git_run(module_path: Path, *args) -> tuple[int, str, str]:
    result = subprocess.run(
        ["git"] + list(args),
        cwd=module_path,
        capture_output=True,
        text=True,
    )
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def is_git_repo(module_path: Path) -> bool:
    code, _, _ = git_run(module_path, "rev-parse", "--is-inside-work-tree")
    return code == 0


def has_uncommitted_changes(module_path: Path) -> bool:
    code, out, _ = git_run(module_path, "status", "--porcelain")
    return bool(out.strip())


def stage_all(module_path: Path) -> bool:
    code, _, err = git_run(module_path, "add", "-A")
    return code == 0


def commit(module_path: Path, message: str) -> tuple[bool, str]:
    code, out, err = git_run(module_path, "commit", "-m", message)
    if code == 0:
        return True, out
    return False, err


def commit_migration(module_path: Path, module_name: str) -> tuple[bool, str]:
    msg = (
        f"chore(hibernate-migration): migrate {module_name} from H5.5 to H7.4\n\n"
        f"Automated migration by hibernate-migrator agent:\n"
        f"- Gradle dependency bump to hibernate-core 7.x\n"
        f"- Oracle dialect updated to OracleDialect\n"
        f"- Session API: save→persist, update→merge, delete→remove\n"
        f"- createSQLQuery → createNativeQuery\n"
        f"- Old Hibernate Criteria API → CriteriaBuilder\n"
        f"- @TypeDef/@Where/@ForeignKey/@Index annotation updates\n"
        f"- UserType interface migrated to H7 signatures\n"
        f"- HQL positional parameter syntax updated\n"
        f"- c3p0 provider updated to H7 integration module\n"
    )
    stage_all(module_path)
    return commit(module_path, msg)
