"""File discovery and safe read/write utilities."""

import shutil
from pathlib import Path
from typing import List


def find_java_files(module_path: Path) -> List[Path]:
    """Return all .java files under src/main/java."""
    src = module_path / "src" / "main" / "java"
    if not src.exists():
        src = module_path / "src"  # fallback
    return sorted(src.rglob("*.java"))


def find_gradle_files(module_path: Path) -> List[Path]:
    """Return build.gradle and any .properties / .xml config files."""
    files = []
    for pattern in ["build.gradle", "build.gradle.kts", "*.properties",
                     "hibernate.cfg.xml", "persistence.xml"]:
        files.extend(module_path.rglob(pattern))
    return files


def read_file(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_file(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def files_containing(java_files: List[Path], *patterns: str) -> List[Path]:
    """Return files whose text contains any of the given substrings."""
    result = []
    for f in java_files:
        text = read_file(f)
        if any(p in text for p in patterns):
            result.append(f)
    return result
