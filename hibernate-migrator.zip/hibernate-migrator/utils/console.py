"""Coloured console output utilities."""


class Console:
    RESET  = "\033[0m"
    BOLD   = "\033[1m"
    RED    = "\033[91m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    BLUE   = "\033[94m"
    CYAN   = "\033[96m"
    GREY   = "\033[90m"

    def _print(self, colour, prefix, msg):
        print(f"{colour}{self.BOLD}{prefix}{self.RESET}{colour} {msg}{self.RESET}")

    def header(self, msg):
        print(f"\n{self.BOLD}{self.CYAN}{'='*60}{self.RESET}")
        print(f"{self.BOLD}{self.CYAN}  {msg}{self.RESET}")
        print(f"{self.BOLD}{self.CYAN}{'='*60}{self.RESET}\n")

    def section(self, msg):
        print(f"\n{self.BOLD}{self.BLUE}── {msg} {'─'*(54-len(msg))}{self.RESET}")

    def separator(self):
        print(f"{self.GREY}{'─'*60}{self.RESET}")

    def info(self, msg):
        self._print(self.CYAN, "[INFO]", msg)

    def success(self, msg):
        self._print(self.GREEN, "[OK]  ", msg)

    def warn(self, msg):
        self._print(self.YELLOW, "[WARN]", msg)

    def error(self, msg):
        self._print(self.RED, "[ERR] ", msg)

    def change(self, msg):
        self._print(self.GREEN, "[CHG] ", msg)

    def skip(self, msg):
        self._print(self.GREY, "[SKIP]", msg)

    def dry(self, msg):
        self._print(self.YELLOW, "[DRY] ", msg)

    def llm(self, msg):
        self._print(self.CYAN, "[LLM] ", msg)
