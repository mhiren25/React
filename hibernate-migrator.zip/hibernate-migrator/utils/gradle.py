"""Gradle compile check after migration."""

import subprocess
from pathlib import Path


def run_compile(module_path: Path) -> tuple[bool, str]:
    """
    Run ./gradlew compileJava from the module root.
    Returns (success, output).
    """
    gradlew = module_path / "gradlew"
    if not gradlew.exists():
        # Walk up to find gradlew in parent dirs
        for parent in module_path.parents:
            if (parent / "gradlew").exists():
                gradlew = parent / "gradlew"
                break

    if not gradlew.exists():
        return False, "gradlew not found in module or any parent directory"

    result = subprocess.run(
        [str(gradlew), "compileJava", "--no-daemon", "--console=plain"],
        cwd=module_path,
        capture_output=True,
        text=True,
        timeout=300,  # 5 minute timeout
    )

    output = result.stdout + result.stderr
    return result.returncode == 0, output
