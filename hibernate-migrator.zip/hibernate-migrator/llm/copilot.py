"""
llm/copilot.py — stub module kept for import compatibility.

GitHub Copilot CLI is no longer used. All LLM-assisted transforms
are handled via the IntelliJ handoff file (llm/handoff.py).
"""

# Retained so existing imports don't break
MAX_BLOCK_CHARS = 3_000


def check_copilot_available() -> tuple[bool, str]:
    return False, "Copilot CLI not used — see handoff file for IntelliJ Copilot Chat tasks"


def migrate_criteria_block(block: str) -> tuple[bool, str]:
    return False, "Not used — handled via IntelliJ handoff file"


def migrate_usertype_class(class_source: str) -> tuple[bool, str]:
    return False, "Not used — handled via IntelliJ handoff file"


def review_hql_query(hql: str) -> tuple[bool, str]:
    return False, "Not used — handled via IntelliJ handoff file"
