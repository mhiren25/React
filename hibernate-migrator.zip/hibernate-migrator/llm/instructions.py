"""
llm/instructions.py — generates .github/copilot-instructions.md in the module root.

This file is the static Hibernate 7 migration context for Copilot Agent mode.
It is written ONCE per module, never repeated per task.
Copilot Agent reads it automatically from .github/copilot-instructions.md.

Content covers:
- What this migration is
- All breaking change patterns with before/after
- Global rules (remove TODO after fixing, don't change unrelated code, etc)
- NO per-task prompts — those are in COPILOT-HANDOFF.md as a simple task list
"""

from pathlib import Path

INSTRUCTIONS_CONTENT = """\
# Hibernate 5.5 → 7.4 Migration — Copilot Agent Instructions

This module is being migrated from Hibernate 5.5 to Hibernate 7.4.
The file `COPILOT-HANDOFF.md` in the module root lists the exact
classes and methods that need fixing, each tagged with a task kind.

Use these instructions to understand what each task kind means and
how to fix it. Navigate to the class/method listed in the handoff
file, apply the fix, and remove the `TODO[hibernate-migration]` comment.

---

## Global Rules

- Fix ONLY the method or class listed in the handoff task
- Do NOT change any surrounding code not related to the migration
- Do NOT add new imports beyond what the fix requires
- After applying a fix, remove the `TODO[hibernate-migration][...]` comment
- Do NOT change StatelessSession.insert/update/delete — those are unchanged in H7
- Do NOT change doWork() / CallableStatement code — that API is unchanged

---

## Task Kind Reference

### CRITERIA
The method uses the old Hibernate 5 Criteria API which is removed in H7.

Migrate to JPA CriteriaBuilder:
```java
// OLD
Criteria c = session.createCriteria(Order.class);
c.add(Restrictions.eq("status", "OPEN"));
List<Order> results = c.list();

// NEW
CriteriaBuilder cb = session.getCriteriaBuilder();
CriteriaQuery<Order> cq = cb.createQuery(Order.class);
Root<Order> root = cq.from(Order.class);
cq.where(cb.equal(root.get("status"), "OPEN"));
List<Order> results = session.createQuery(cq).getResultList();
```

Common mappings:
- Restrictions.eq/ne/gt/lt/ge/le → cb.equal/notEqual/gt/lt/ge/le
- Restrictions.like → cb.like
- Restrictions.isNull/isNotNull → cb.isNull/isNotNull
- Restrictions.and/or → cb.and/or
- Restrictions.in → root.get("field").in(list)
- Restrictions.between → cb.between
- Projections.rowCount() → cb.count(root)
- Order.asc/desc → cb.asc/desc(root.get("field"))
- criteria.setMaxResults/setFirstResult → query.setMaxResults/setFirstResult
- criteria.list() → session.createQuery(cq).getResultList()
- criteria.uniqueResult() → session.createQuery(cq).getSingleResultOrNull()

---

### JAKARTA
The method or field uses `javax.persistence.*` annotations or types.
Replace all `javax.persistence` with `jakarta.persistence`.
Also replace `javax.transaction.Synchronization` → `jakarta.transaction.Synchronization`.

```java
// OLD
import javax.persistence.Entity;
import javax.persistence.Column;
@javax.persistence.Transient

// NEW
import jakarta.persistence.Entity;
import jakarta.persistence.Column;
@jakarta.persistence.Transient
```

---

### USERTYPE
The class implements the Hibernate 5 `UserType` interface which changed in H7.

Key changes:
- `nullSafeGet` signature: `(ResultSet rs, int position, SharedSessionContractImplementor session, Object owner)`
- `nullSafeSet` signature: `(PreparedStatement st, T value, int index, SharedSessionContractImplementor session)`
- `sqlTypes()` returning `int[]` → `getSqlType()` returning single `int`
- `returnedClass()` → returns `Class<T>` (generic)
- `SessionImplementor` → `SharedSessionContractImplementor`

---

### NATIVE-QUERY
The method uses removed or changed NativeQuery API.

```java
// setResultTransformer removed — replace with stream mapping or typed query
// OLD
query.setResultTransformer(Transformers.aliasToBean(MyDto.class));
List<MyDto> results = query.list();

// NEW (option 1 — typed native query)
List<MyDto> results = session.createNativeQuery(sql, MyDto.class).getResultList();

// NEW (option 2 — stream map)
List<Object[]> rows = session.createNativeQuery(sql).getResultList();
List<MyDto> results = rows.stream()
    .map(row -> new MyDto((String) row[0], (Integer) row[1]))
    .collect(Collectors.toList());
```

---

### INTERCEPTOR
The class extends `EmptyInterceptor` which is removed in H7.

```java
// OLD
public class MyInterceptor extends EmptyInterceptor {
    @Override
    public boolean onSave(Object entity, Serializable id, ...) { ... }
}

// NEW
public class MyInterceptor implements Interceptor {
    // 1. Change extends → implements
    // 2. Fix import: org.hibernate.EmptyInterceptor → org.hibernate.Interceptor
    // 3. Rename onSave → onPersist
    // 4. Change id param: Serializable → Object in all methods
    // 5. Change postFlush(Iterator) → postFlush(Iterator<Object>)
    // 6. Remove all super.onXxx() calls — Interceptor has default no-ops
    // 7. Remove serialVersionUID — class no longer needs to be Serializable
}
```

---

### SPRING-ORM
The method uses Spring-orm Hibernate integration which must be replaced
with pure Hibernate 7 native API. Spring DI (@Autowired, @Component etc) stays.

**LocalSessionFactoryBean → manual Configuration:**
```java
// Remove LocalSessionFactoryBean @Bean method, replace with:
@Bean
public SessionFactory sessionFactory() {
    Configuration config = new Configuration();
    config.setProperty("hibernate.dialect", "org.hibernate.dialect.OracleDialect");
    config.addAnnotatedClass(MyEntity.class); // repeat for each entity
    ServiceRegistry registry = new StandardServiceRegistryBuilder()
        .applySetting(Environment.DATASOURCE, dataSource)
        .build();
    return config.buildSessionFactory(registry);
}
```

**HibernateTransactionManager → remove entirely:**
Remove the @Bean method — transactions are now managed manually per method.

**HibernateTemplate/HibernateDaoSupport → direct Session:**
```java
// OLD
public class MyDao extends HibernateDaoSupport {
    public void save(Order o) { getHibernateTemplate().save(o); }
}

// NEW
public class MyDao {
    @Autowired private SessionFactory sessionFactory;

    public void save(Order o) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            try { session.persist(o); tx.commit(); }
            catch (Exception e) { tx.rollback(); throw e; }
        }
    }
}
```

**@Transactional → manual transaction:**
```java
// OLD
@Transactional
public void processOrder(Order o) { ... }

// NEW — remove @Transactional, wrap body:
public void processOrder(Order o) {
    Transaction tx = null;
    try (Session session = sessionFactory.openSession()) {
        tx = session.beginTransaction();
        // existing body here
        tx.commit();
    } catch (Exception e) {
        if (tx != null) tx.rollback();
        throw e;
    }
}
```

---

### STATELESS-CONNECTION
The method calls `statelessSession.connection()` which is removed in H7.

```java
// OLD
Connection conn = statelessSession.connection();
// ... jdbc code using conn ...

// NEW
statelessSession.doWork(connection -> {
    // ... same jdbc code, using 'connection' ...
});

// If return value needed:
T result = statelessSession.doReturningWork(connection -> {
    // ... jdbc code ...
    return someValue;
});
```

---

### TRANSACTION-IFACE
The class implements `org.hibernate.Transaction` which gained new required methods in H7.

Add these methods to the class:
```java
@Override
public void markRollbackOnly() {
    // delegate to your existing rollback mechanism
}

@Override
public void setTimeout(int seconds) {
    setTimeout(Integer.valueOf(seconds));
}

@Override
public void setTimeout(Integer seconds) {
    // existing logic
}

@Override
public Integer getTimeout() {  // was int, now Integer
    // existing logic
}
```

---

### ID-GENERATOR
The class is a custom Hibernate ID generator with changed signatures in H7.

```java
// generate() return type: Serializable → Object
@Override
public Object generate(SharedSessionContractImplementor session, Object owner) {
    // existing logic unchanged
}

// configure() is deprecated — add suppression if still overriding:
@Override
@SuppressWarnings("removal")
public void configure(Type type, Properties params, ServiceRegistry serviceRegistry) {
    // existing logic unchanged
}
```

---

### HIKARI-INIT-SQL
The class extends `AbstractConnectionCustomizer` which is removed in the
c3p0 version bundled with `hibernate-c3p0:7.x`.

**Delete this class entirely.**

The replacement is a `HikariDataSource` subclass that calls the same
DB login logic in an overridden `getConnection()`:

```java
public class DbLoginHikariDataSource extends HikariDataSource {
    public DbLoginHikariDataSource(HikariConfig config) { super(config); }

    @Override
    public Connection getConnection() throws SQLException {
        Connection connection = super.getConnection();
        try {
            new DbUtils().login(connection);
        } catch (Exception e) {
            throw new SQLException("DB login failed", e);
        }
        return connection;
    }
}
```

Wire into SessionFactory via ServiceRegistry (not CONNECTION_PROVIDER string):
```java
ServiceRegistry registry = new StandardServiceRegistryBuilder()
    .applySetting(Environment.DATASOURCE, new DbLoginHikariDataSource(hikariConfig))
    .build();
SessionFactory sf = config.buildSessionFactory(registry);
```

---

### PROGRAMMATIC-DATASOURCE
The method builds a SessionFactory using programmatic `Configuration.setProperty()`
calls for c3p0/connection settings. Replace with HikariCP DataSource object approach.

```java
// OLD — string properties, c3p0 provider
config.setProperty(Environment.CONNECTION_PROVIDER, "...C3P0ConnectionProvider");
config.setProperty(Environment.URL, url);
config.setProperty(Environment.USER, user);
config.setProperty(Environment.PASS, pass);
config.setProperty("hibernate.c3p0.connectionCustomizerClassName", "...");

// NEW — build DataSource object, pass via ServiceRegistry
HikariConfig hikariConfig = new HikariConfig();
hikariConfig.setJdbcUrl(url);        // same value as Environment.URL
hikariConfig.setUsername(user);      // same value as Environment.USER
hikariConfig.setPassword(pass);      // same value as Environment.PASS
hikariConfig.setMaximumPoolSize(10);
hikariConfig.setMinimumIdle(2);
hikariConfig.setConnectionTimeout(30_000);

// Use custom subclass if DB login logic was in a ConnectionCustomizer:
DataSource dataSource = new DbLoginHikariDataSource(hikariConfig);

ServiceRegistry registry = new StandardServiceRegistryBuilder()
    .applySetting(Environment.DATASOURCE, dataSource)
    .build();
SessionFactory sf = config.buildSessionFactory(registry);
```

---

## Dialect

All Oracle dialect variants → single unified dialect:
```properties
# OLD (any of these)
org.hibernate.dialect.Oracle10gDialect
org.hibernate.dialect.Oracle12cDialect
org.hibernate.dialect.Oracle9iDialect

# NEW
org.hibernate.dialect.OracleDialect
```
"""


def generate(module_path: Path, console) -> Path:
    """
    Write .github/copilot-instructions.md in the module root.
    Creates .github/ directory if it doesn't exist.
    Returns path to the written file.
    """
    github_dir = module_path / ".github"
    github_dir.mkdir(exist_ok=True)

    instructions_path = github_dir / "copilot-instructions.md"
    instructions_path.write_text(INSTRUCTIONS_CONTENT, encoding="utf-8")
    console.success(
        f"Copilot Agent instructions written: "
        f".github/copilot-instructions.md "
        f"({len(INSTRUCTIONS_CONTENT.splitlines())} lines)"
    )
    return instructions_path
