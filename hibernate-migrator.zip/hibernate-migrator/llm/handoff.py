"""
llm/handoff.py — lean per-module COPILOT-HANDOFF.md generator.

Design (revised):
  - ONE flat checklist per module: ClassName.methodName() — task kind
  - NO code blocks, NO per-task prompts, NO repeated context
  - Migration context lives in .github/copilot-instructions.md (static, written once)
  - Copilot Agent navigates to the class/method itself — no need to paste source
  - Only methods/fields ACTUALLY IMPACTED by the migration are listed
  - TODO removal is covered globally in copilot-instructions.md, not per task

The agent detects impact at METHOD level (not class level) by:
  - Scanning method bodies for old API patterns
  - Mapping each hit to the containing method name + class name
  - One task line per impacted method, grouped by class
"""

import re
from dataclasses import dataclass, field
from pathlib import Path
from datetime import datetime
from utils.files import find_java_files, read_file, write_file


# ── Data model ────────────────────────────────────────────────────────────────

@dataclass
class HandoffTask:
    kind: str           # task kind matching copilot-instructions.md section
    file_rel: str       # relative path from module root
    class_name: str     # Java class name
    method_name: str    # method name (or field name for field-level issues)
    line_start: int     # 1-based line in file


# ── Method extraction ─────────────────────────────────────────────────────────

def _extract_class_name(content: str) -> str:
    """Extract the primary class name from a Java file."""
    m = re.search(r'\bclass\s+(\w+)', content)
    return m.group(1) if m else "UnknownClass"


def _extract_methods(content: str) -> list[tuple[str, int, int, str]]:
    """
    Extract (method_name, start_line_0, end_line_0, method_body) for every
    method in the file. Includes the annotation lines immediately preceding
    the method signature so @Transactional is captured in the body.
    Uses brace-depth matching.
    """
    results = []
    lines = content.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]
        m = re.search(r'\b(public|private|protected)\b[^(]+\b(\w+)\s*\(', line)
        if m and '{' in line:
            method_name = m.group(2)
            # Look back up to 5 lines for annotations to include them in body
            annotation_start = i
            for back in range(1, 6):
                if i - back >= 0 and (
                    lines[i - back].strip().startswith("@")
                    or lines[i - back].strip() == ""
                ):
                    annotation_start = i - back
                else:
                    break
            depth = line.count('{') - line.count('}')
            j = i + 1
            while j < len(lines) and depth > 0:
                depth += lines[j].count('{') - lines[j].count('}')
                j += 1
            body = "\n".join(lines[annotation_start:j])
            results.append((method_name, annotation_start, j, body))
            i = j
        else:
            i += 1
    return results


# ── Per-kind method-level detectors ──────────────────────────────────────────

CRITERIA_SIGNALS = [
    "createCriteria(", "Restrictions.", "Projections.",
    "org.hibernate.Criteria", "org.hibernate.criterion",
]

JAKARTA_SIGNALS = ["javax.persistence.", "javax.transaction.Synchronization"]

USERTYPE_SIGNALS = ["implements UserType", "implements CompositeUserType"]

NATIVE_QUERY_SIGNALS = ["setResultTransformer(", "addScalar("]

SPRING_ORM_SIGNALS = [
    "HibernateTemplate", "HibernateDaoSupport",
    "LocalSessionFactoryBean", "HibernateTransactionManager",
    "@Transactional",
]

INTERCEPTOR_SIGNALS = ["extends EmptyInterceptor"]

STATELESS_CONN_SIGNALS = [".connection()"]

TRANSACTION_IFACE_SIGNALS = ["implements Transaction", "implements org.hibernate.Transaction"]

ID_GEN_SIGNALS = ["TableInstanceHiLoGenerator", "implements IdentifierGenerator"]

HIKARI_SIGNALS = ["AbstractConnectionCustomizer"]

DATASOURCE_SIGNALS = [
    "Environment.CONNECTION_PROVIDER", "Environment.URL", "Environment.USER",
    "Environment.PASS", "hibernate.c3p0.", "C3P0ConnectionProvider",
]


def _methods_matching(methods: list, *signals: str) -> list[tuple[str, int]]:
    """Return (method_name, start_line_1based) for methods whose body contains any signal."""
    return [
        (name, start + 1)
        for name, start, _, body in methods
        if any(s in body for s in signals)
    ]


def _class_level_match(content: str, *signals: str) -> bool:
    """True if any signal appears anywhere in the file (for class-level issues)."""
    return any(s in content for s in signals)


# ── TODO insertion (inline in Java files) ─────────────────────────────────────

_TODO_TEMPLATES = {
    "CRITERIA":               "// TODO[hibernate-migration][CRITERIA] Migrate Criteria API → CriteriaBuilder. See .github/copilot-instructions.md",
    "JAKARTA":                "// TODO[hibernate-migration][JAKARTA] Replace javax.persistence → jakarta.persistence. See .github/copilot-instructions.md",
    "USERTYPE":               "// TODO[hibernate-migration][USERTYPE] Migrate UserType interface to H7 signatures. See .github/copilot-instructions.md",
    "NATIVE-QUERY":           "// TODO[hibernate-migration][NATIVE-QUERY] setResultTransformer removed in H7. See .github/copilot-instructions.md",
    "SPRING-ORM":             "// TODO[hibernate-migration][SPRING-ORM] Replace Spring-orm with pure Hibernate 7. See .github/copilot-instructions.md",
    "INTERCEPTOR":            "// TODO[hibernate-migration][INTERCEPTOR] EmptyInterceptor removed — implements Interceptor. See .github/copilot-instructions.md",
    "STATELESS-CONNECTION":   "// TODO[hibernate-migration][STATELESS-CONNECTION] .connection() removed — use doWork(). See .github/copilot-instructions.md",
    "TRANSACTION-IFACE":      "// TODO[hibernate-migration][TRANSACTION-IFACE] Transaction interface changed in H7. See .github/copilot-instructions.md",
    "ID-GENERATOR":           "// TODO[hibernate-migration][ID-GENERATOR] Generator signatures changed in H7. See .github/copilot-instructions.md",
    "HIKARI-INIT-SQL":        "// TODO[hibernate-migration][HIKARI-INIT-SQL] Delete class — replace with HikariDataSource subclass. See .github/copilot-instructions.md",
    "PROGRAMMATIC-DATASOURCE":"// TODO[hibernate-migration][PROGRAMMATIC-DATASOURCE] Replace c3p0 setProperty() with HikariCP DataSource. See .github/copilot-instructions.md",
}


def _insert_todo(content: str, line_idx: int, kind: str) -> str:
    """Insert a TODO comment before the given 0-based line, if not already present."""
    lines = content.split("\n")
    # Check surrounding lines for existing TODO of same kind
    check_range = lines[max(0, line_idx-2):line_idx+1]
    if any(f"TODO[hibernate-migration][{kind}]" in l for l in check_range):
        return content
    indent = " " * (len(lines[line_idx]) - len(lines[line_idx].lstrip()))
    todo = indent + _TODO_TEMPLATES.get(kind, f"// TODO[hibernate-migration][{kind}]")
    lines.insert(line_idx, todo)
    return "\n".join(lines)


# ── Main scanner ──────────────────────────────────────────────────────────────

def _scan_file(
    java_file: Path,
    module_path: Path,
    dry_run: bool,
    extra_tasks: list[dict],
) -> list[HandoffTask]:
    """
    Scan one Java file for migration issues at method level.
    Insert inline TODO comments. Return HandoffTask list.
    """
    content = read_file(java_file)
    rel = str(java_file.relative_to(module_path))
    class_name = _extract_class_name(content)
    methods = _extract_methods(content)
    tasks: list[HandoffTask] = []
    modified = content

    def _add(kind: str, method_name: str, line: int):
        tasks.append(HandoffTask(
            kind=kind,
            file_rel=rel,
            class_name=class_name,
            method_name=method_name,
            line_start=line,
        ))
        nonlocal modified
        if not dry_run:
            modified = _insert_todo(modified, line - 1, kind)

    # ── Method-level scans ────────────────────────────────────────────────────

    for name, line in _methods_matching(methods, *CRITERIA_SIGNALS):
        _add("CRITERIA", name, line)

    for name, line in _methods_matching(methods, *JAKARTA_SIGNALS):
        _add("JAKARTA", name, line)

    for name, line in _methods_matching(methods, *NATIVE_QUERY_SIGNALS):
        _add("NATIVE-QUERY", name, line)

    for name, line in _methods_matching(methods, *SPRING_ORM_SIGNALS):
        _add("SPRING-ORM", name, line)

    for name, line in _methods_matching(methods, *STATELESS_CONN_SIGNALS):
        _add("STATELESS-CONNECTION", name, line)

    for name, line in _methods_matching(methods, *DATASOURCE_SIGNALS):
        _add("PROGRAMMATIC-DATASOURCE", name, line)

    # ── Class-level scans (whole-class structural change) ────────────────────

    if _class_level_match(content, *USERTYPE_SIGNALS):
        _add("USERTYPE", class_name, 1)

    if _class_level_match(content, *INTERCEPTOR_SIGNALS):
        _add("INTERCEPTOR", class_name, 1)

    if _class_level_match(content, *TRANSACTION_IFACE_SIGNALS):
        _add("TRANSACTION-IFACE", class_name, 1)

    if _class_level_match(content, *ID_GEN_SIGNALS):
        _add("ID-GENERATOR", class_name, 1)

    if _class_level_match(content, *HIKARI_SIGNALS):
        _add("HIKARI-INIT-SQL", class_name, 1)

    # ── Jakarta field-level scan (annotations on fields, not inside methods) ──
    # Fields with javax.persistence annotations aren't inside method bodies,
    # so we add a class-level JAKARTA task if the file has javax.persistence
    # AND we didn't already catch it via method-level scan above.
    if _class_level_match(content, *JAKARTA_SIGNALS):
        already = any(t.kind == "JAKARTA" for t in tasks)
        if not already:
            _add("JAKARTA", class_name, 1)

    if not dry_run and modified != content:
        write_file(java_file, modified)

    return tasks


# ── Handoff markdown builder ──────────────────────────────────────────────────

def _build_handoff_md(module_name: str, tasks: list[HandoffTask]) -> str:
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    # Group by file → class → methods
    # file_rel → class_name → list of (method_name, kind, line)
    grouped: dict[str, dict[str, list[tuple[str, str, int]]]] = {}
    for t in tasks:
        grouped.setdefault(t.file_rel, {}).setdefault(t.class_name, []).append(
            (t.method_name, t.kind, t.line_start)
        )

    # Count by kind
    kind_counts: dict[str, int] = {}
    for t in tasks:
        kind_counts[t.kind] = kind_counts.get(t.kind, 0) + 1
    kind_summary = ", ".join(f"{v} {k}" for k, v in sorted(kind_counts.items()))

    lines = [
        f"# Copilot Agent Migration Tasks — `{module_name}`",
        f"",
        f"Generated: {now}  ",
        f"Total: **{len(tasks)} task(s)** — {kind_summary}",
        f"",
        f"Migration context and fix instructions: `.github/copilot-instructions.md`",
        f"",
        f"> Ask Copilot Agent: **\"Fix all TODO[hibernate-migration] items in this module",
        f"> using the instructions in .github/copilot-instructions.md\"**",
        f"> — or work through each task below individually.",
        f"",
        f"---",
        f"",
        f"## Tasks by File",
        f"",
    ]

    task_num = 1
    for file_rel, classes in grouped.items():
        lines.append(f"### `{file_rel}`")
        lines.append("")
        for class_name, method_entries in classes.items():
            lines.append(f"**{class_name}**")
            lines.append("")
            for method_name, kind, line_num in method_entries:
                lines.append(
                    f"- [ ] {task_num}. `{method_name}` — **{kind}** _(line {line_num})_"
                )
                task_num += 1
            lines.append("")

    lines += [
        "---",
        "",
        "## After completing all tasks",
        "",
        "```bash",
        "# Verify no TODOs remain",
        "grep -rn \"TODO\\[hibernate-migration\\]\" src/",
        "",
        "# Compile check",
        "./gradlew compileJava",
        "",
        "# Commit",
        "git add -A && git commit -m \"chore: complete Copilot migration tasks\"",
        "```",
    ]

    return "\n".join(lines) + "\n"


# ── Public API ────────────────────────────────────────────────────────────────

def generate(
    module_path: Path,
    dry_run: bool,
    console,
    extra_tasks: list[dict] | None = None,
) -> tuple[int, Path | None]:
    """
    Scan module for migration issues at method level.
    Insert inline TODO comments. Write lean COPILOT-HANDOFF.md.
    Returns (task_count, handoff_path).
    """
    tasks: list[HandoffTask] = []

    # Scan all Java files for method-level issues
    for java_file in find_java_files(module_path):
        file_tasks = _scan_file(java_file, module_path, dry_run, extra_tasks or [])
        tasks.extend(file_tasks)

    # Convert extra_tasks (dict form from other transforms) to HandoffTask
    # These are already detected and TODO-inserted by their own transforms —
    # here we just add them to the handoff checklist
    for t in (extra_tasks or []):
        # Only add if not already captured by file scan above
        already = any(
            ht.file_rel == t["file_rel"] and ht.kind == t["kind"]
            for ht in tasks
        )
        if not already:
            tasks.append(HandoffTask(
                kind=t["kind"],
                file_rel=t["file_rel"],
                class_name=t.get("class_name", t["file_rel"].split("/")[-1].replace(".java", "")),
                method_name=t.get("method_name", t["description"]),
                line_start=t["line_start"],
            ))

    if not tasks:
        console.skip("No migration issues found — COPILOT-HANDOFF.md not written")
        return 0, None

    handoff_path = module_path / "COPILOT-HANDOFF.md"
    handoff_content = _build_handoff_md(module_path.name, tasks)

    if not dry_run:
        write_file(handoff_path, handoff_content)
        console.success(
            f"Handoff written: COPILOT-HANDOFF.md "
            f"({len(tasks)} task(s) across {len(set(t.file_rel for t in tasks))} file(s))"
        )
    else:
        console.dry(f"Would write COPILOT-HANDOFF.md with {len(tasks)} task(s)")

    return len(tasks), handoff_path if not dry_run else None
