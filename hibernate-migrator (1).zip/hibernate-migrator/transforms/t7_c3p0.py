"""
Transform 7: c3p0 provider class name update.

In H7 the c3p0 connection provider class moved.
Also flags testConnectionOnCheckin for manual semantic review.
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files


OLD_PROVIDER = "org.hibernate.connection.C3P0ConnectionProvider"
NEW_PROVIDER = "org.hibernate.c3p0.internal.C3P0ConnectionProvider"

# Warn if testConnectionOnCheckin found — may need to be onAcquire() instead
CHECKIN_WARN = (
    "testConnectionOnCheckin found — verify this is the correct hook. "
    "If requirement is 'first query on new physical connection', "
    "use connectionCustomizerClassName with onAcquire() instead."
)


def apply(module_path: Path, dry_run: bool, console) -> int:
    changed = 0

    all_files = list(find_java_files(module_path))
    # Also check properties and xml
    for pattern in ["**/*.properties", "**/hibernate.cfg.xml"]:
        all_files.extend(module_path.rglob(pattern.lstrip("**/")))

    for f in all_files:
        if not f.is_file():
            continue
        original = read_file(f)
        content = original
        rel = f.relative_to(module_path)

        # Fix provider class
        if OLD_PROVIDER in content:
            content = content.replace(OLD_PROVIDER, NEW_PROVIDER)
            if dry_run:
                console.dry(f"{rel}: would update c3p0 provider class")
            else:
                console.change(f"{rel}: c3p0 provider → {NEW_PROVIDER}")
            changed += 1

        # Warn about testConnectionOnCheckin
        if "testConnectionOnCheckin" in content:
            console.warn(f"{rel}: {CHECKIN_WARN}")

        if not dry_run and content != original:
            write_file(f, content)

    return changed
