"""
Transform 1: Gradle dependency version bump.
Updates hibernate-core, hibernate-c3p0, hibernate-validator in build.gradle.
"""

import re
from pathlib import Path
from utils.files import read_file, write_file


H7_VERSION = "7.0.4.Final"
VALIDATOR_VERSION = "8.0.1.Final"

# Old group IDs and their new equivalents
REPLACEMENTS = [
    # hibernate-core group change
    (r"org\.hibernate:hibernate-core:[^\s'\"]+",
     f"org.hibernate.orm:hibernate-core:{H7_VERSION}"),

    # hibernate-c3p0
    (r"org\.hibernate:hibernate-c3p0:[^\s'\"]+",
     f"org.hibernate.orm:hibernate-c3p0:{H7_VERSION}"),

    # hibernate-validator
    (r"org\.hibernate:hibernate-validator:[^\s'\"]+",
     f"org.hibernate.validator:hibernate-validator:{VALIDATOR_VERSION}"),

    # hibernate-entitymanager (should not be present but clean up if found)
    (r"org\.hibernate:hibernate-entitymanager:[^\s'\"]+",
     f"// REMOVED: hibernate-entitymanager is bundled in hibernate-core {H7_VERSION}"),

    # javax.persistence-api — only if present
    (r"javax\.persistence:javax\.persistence-api:[^\s'\"]+",
     "// REMOVED: javax.persistence replaced — check if jakarta.persistence-api needed"),
]


def apply(module_path: Path, dry_run: bool, console) -> int:
    """Returns count of changes made."""
    build_gradle = module_path / "build.gradle"
    build_gradle_kts = module_path / "build.gradle.kts"

    changed = 0
    for gradle_file in [build_gradle, build_gradle_kts]:
        if not gradle_file.exists():
            continue

        original = read_file(gradle_file)
        content = original

        for pattern, replacement in REPLACEMENTS:
            new_content = re.sub(pattern, replacement, content)
            if new_content != content:
                matches = re.findall(pattern, content)
                for m in matches:
                    if dry_run:
                        console.dry(f"build.gradle: would replace '{m}' → '{replacement}'")
                    else:
                        console.change(f"build.gradle: '{m}' → '{replacement}'")
                    changed += 1
                content = new_content

        if not dry_run and content != original:
            write_file(gradle_file, content)

    return changed
