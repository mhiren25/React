"""
Transform 6: LLM-assisted transforms via GitHub Copilot CLI.

Handles the two cases that regex/AST cannot safely handle:
  1. Hibernate 5 Criteria API → CriteriaBuilder
  2. UserType interface migration to H7 signatures

Strategy:
  - Find files containing old Criteria / UserType patterns
  - Extract the relevant block (class or method)
  - Send to Copilot CLI one block at a time (under MAX_BLOCK_CHARS)
  - Apply response back to file
  - Flag anything too large for LLM with a TODO comment
"""

import re
from pathlib import Path
from utils.files import read_file, write_file, find_java_files, files_containing
from llm.copilot import (
    migrate_criteria_block,
    migrate_usertype_class,
    MAX_BLOCK_CHARS,
)


# ── Criteria detection ────────────────────────────────────────────────────────

CRITERIA_IMPORTS = [
    "import org.hibernate.Criteria;",
    "import org.hibernate.criterion.Restrictions;",
    "import org.hibernate.criterion.Projections;",
    "import org.hibernate.criterion.Order;",
    "import org.hibernate.criterion.Criterion;",
]

CRITERIA_USAGE = ["createCriteria(", "Restrictions.", "Projections."]


def _has_criteria(content: str) -> bool:
    return any(p in content for p in CRITERIA_IMPORTS + CRITERIA_USAGE)


def _extract_criteria_methods(content: str) -> list[tuple[int, int, str]]:
    """
    Extract method bodies that contain Criteria usage.
    Returns list of (start_line, end_line, method_text).
    Simplified: finds methods by brace matching.
    """
    results = []
    lines = content.split('\n')

    i = 0
    while i < len(lines):
        line = lines[i]
        # Look for method signatures followed by a block containing Criteria
        if re.search(r'\b(public|private|protected)\b.*\{', line):
            # Collect the method block
            depth = line.count('{') - line.count('}')
            method_lines = [line]
            start = i
            j = i + 1
            while j < len(lines) and depth > 0:
                method_lines.append(lines[j])
                depth += lines[j].count('{') - lines[j].count('}')
                j += 1
            method_text = '\n'.join(method_lines)
            if any(p in method_text for p in CRITERIA_USAGE):
                results.append((start, j, method_text))
            i = j
        else:
            i += 1

    return results


# ── UserType detection ────────────────────────────────────────────────────────

def _has_usertype(content: str) -> bool:
    return (
        'implements UserType' in content or
        'implements CompositeUserType' in content or
        'import org.hibernate.usertype.UserType' in content
    )


# ── Main apply ────────────────────────────────────────────────────────────────

def apply(module_path: Path, dry_run: bool, console, skip_llm: bool = False) -> int:
    changed = 0
    java_files = find_java_files(module_path)

    # ── Criteria migration ──
    criteria_files = [f for f in java_files if _has_criteria(read_file(f))]

    for java_file in criteria_files:
        original = read_file(java_file)
        rel = java_file.relative_to(module_path)

        if skip_llm:
            console.warn(f"{rel}: contains Criteria API — LLM disabled, flagging with TODO")
            # Insert TODO at top of file
            todo = (
                "// TODO[hibernate-migration]: This file contains Hibernate 5 Criteria API.\n"
                "// Migrate createCriteria()/Restrictions/Projections to CriteriaBuilder.\n"
                "// See migration plan for patterns.\n"
            )
            if not dry_run:
                write_file(java_file, todo + original)
            changed += 1
            continue

        methods = _extract_criteria_methods(original)
        if not methods:
            console.warn(f"{rel}: Criteria detected but method extraction found nothing — flag manually")
            continue

        content = original
        offset = 0  # line offset as we replace

        for start, end, method_text in methods:
            if len(method_text) > MAX_BLOCK_CHARS:
                console.warn(
                    f"{rel}: method at line {start+1} too large for LLM "
                    f"({len(method_text)} chars) — flagging with TODO"
                )
                todo_line = (
                    f"    // TODO[hibernate-migration]: Criteria block too large for auto-migration "
                    f"— migrate manually\n"
                )
                lines = content.split('\n')
                lines.insert(start + offset, todo_line)
                content = '\n'.join(lines)
                offset += 1
                changed += 1
                continue

            console.llm(f"{rel}: sending Criteria method (line {start+1}) to Copilot...")
            if dry_run:
                console.dry(f"{rel}: would send Criteria block to Copilot (line {start+1})")
                changed += 1
                continue

            success, migrated = migrate_criteria_block(method_text)
            if not success:
                console.warn(f"{rel}: Copilot failed for block at line {start+1} — {migrated}")
                todo_line = (
                    f"    // TODO[hibernate-migration]: Copilot migration failed — "
                    f"migrate this Criteria block manually\n"
                )
                lines = content.split('\n')
                lines.insert(start + offset, todo_line)
                content = '\n'.join(lines)
                offset += 1
                changed += 1
                continue

            # Replace method block in content
            lines = content.split('\n')
            migrated_lines = migrated.split('\n')
            lines[start + offset: end + offset] = migrated_lines
            content = '\n'.join(lines)
            offset += len(migrated_lines) - (end - start)
            console.change(f"{rel}: Criteria method at line {start+1} migrated via Copilot")
            changed += 1

        if not dry_run and content != original:
            write_file(java_file, content)

    # ── UserType migration ──
    usertype_files = [f for f in java_files if _has_usertype(read_file(f))]

    for java_file in usertype_files:
        original = read_file(java_file)
        rel = java_file.relative_to(module_path)

        if skip_llm:
            console.warn(f"{rel}: implements UserType — LLM disabled, flagging with TODO")
            todo = (
                "// TODO[hibernate-migration]: UserType interface changed in H7.\n"
                "// Update: nullSafeGet/Set signatures, getSqlType() replaces sqlTypes(),\n"
                "// SharedSessionContractImplementor replaces SessionImplementor.\n"
            )
            if not dry_run:
                write_file(java_file, todo + original)
            changed += 1
            continue

        if len(original) > MAX_BLOCK_CHARS:
            console.warn(f"{rel}: UserType class too large ({len(original)} chars) — flagging with TODO")
            todo = (
                "// TODO[hibernate-migration]: UserType class too large for auto-migration.\n"
                "// Migrate manually: update nullSafeGet/Set, getSqlType(), "
                "SharedSessionContractImplementor.\n"
            )
            if not dry_run:
                write_file(java_file, todo + original)
            changed += 1
            continue

        console.llm(f"{rel}: sending UserType class to Copilot...")
        if dry_run:
            console.dry(f"{rel}: would send UserType class to Copilot")
            changed += 1
            continue

        success, migrated = migrate_usertype_class(original)
        if not success:
            console.warn(f"{rel}: Copilot failed for UserType — {migrated}")
            todo = (
                f"// TODO[hibernate-migration]: Auto-migration failed ({migrated}).\n"
                f"// Migrate manually.\n"
            )
            if not dry_run:
                write_file(java_file, todo + original)
        else:
            console.change(f"{rel}: UserType class migrated via Copilot")
            if not dry_run:
                write_file(java_file, migrated)

        changed += 1

    return changed
