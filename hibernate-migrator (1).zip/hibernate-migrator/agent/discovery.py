"""
Discovery scanner — analyses a module and reports what needs migration.
Runs before any transform is applied.
"""

import re
from dataclasses import dataclass, field
from pathlib import Path
from utils.files import find_java_files, read_file


@dataclass
class DiscoveryResult:
    module_path: Path
    java_files: list[Path] = field(default_factory=list)

    # Counts per category
    dialect_hits: list[str] = field(default_factory=list)
    session_api_hits: list[str] = field(default_factory=list)
    criteria_hits: list[str] = field(default_factory=list)
    native_sql_hits: list[str] = field(default_factory=list)
    annotation_hits: list[str] = field(default_factory=list)
    usertype_hits: list[str] = field(default_factory=list)
    hql_hits: list[str] = field(default_factory=list)
    c3p0_hits: list[str] = field(default_factory=list)
    dowork_hits: list[str] = field(default_factory=list)
    validator_javax: list[str] = field(default_factory=list)
    validator_jakarta: list[str] = field(default_factory=list)

    @property
    def has_anything(self) -> bool:
        return any([
            self.dialect_hits, self.session_api_hits, self.criteria_hits,
            self.native_sql_hits, self.annotation_hits, self.usertype_hits,
            self.hql_hits, self.c3p0_hits,
        ])

    @property
    def needs_llm(self) -> bool:
        return bool(self.criteria_hits or self.usertype_hits)


def scan(module_path: Path) -> DiscoveryResult:
    result = DiscoveryResult(module_path=module_path)
    result.java_files = find_java_files(module_path)

    old_dialects = [
        "Oracle10gDialect", "Oracle12cDialect", "Oracle9iDialect", "OracleLegacyDialect"
    ]

    for java_file in result.java_files:
        content = read_file(java_file)
        rel = str(java_file.relative_to(module_path))

        # Dialect
        if any(d in content for d in old_dialects):
            result.dialect_hits.append(rel)

        # Session API
        if re.search(r'\.(save|update|saveOrUpdate|delete)\s*\(', content):
            result.session_api_hits.append(rel)

        # Criteria
        if any(p in content for p in [
            'createCriteria(', 'Restrictions.', 'Projections.',
            'import org.hibernate.Criteria', 'import org.hibernate.criterion'
        ]):
            result.criteria_hits.append(rel)

        # Native SQL
        if 'createSQLQuery(' in content:
            result.native_sql_hits.append(rel)

        # Annotations
        if any(p in content for p in [
            '@TypeDef', '@TypeDefs', '@Where', '@ForeignKey',
            'org.hibernate.annotations.Index', '@Type(type='
        ]):
            result.annotation_hits.append(rel)

        # UserType
        if 'implements UserType' in content or 'implements CompositeUserType' in content:
            result.usertype_hits.append(rel)

        # HQL with bare ?
        if 'createQuery(' in content and re.search(r'"\s*[^"]*\?(?!\d)[^"]*"', content):
            result.hql_hits.append(rel)

        # doWork / SP
        if 'doWork(' in content or 'CallableStatement' in content:
            result.dowork_hits.append(rel)

        # Validator
        if 'import javax.validation' in content:
            result.validator_javax.append(rel)
        if 'import jakarta.validation' in content:
            result.validator_jakarta.append(rel)

    # c3p0 config files
    for f in module_path.rglob("*.properties"):
        content = read_file(f)
        if 'c3p0' in content or 'C3P0' in content:
            result.c3p0_hits.append(str(f.relative_to(module_path)))
    for f in module_path.rglob("hibernate.cfg.xml"):
        content = read_file(f)
        if 'c3p0' in content.lower():
            result.c3p0_hits.append(str(f.relative_to(module_path)))

    return result


def print_discovery(result: DiscoveryResult, console) -> None:
    console.section("Discovery Scan")
    console.info(f"Java files found: {len(result.java_files)}")

    sections = [
        ("Dialect changes needed",        result.dialect_hits,      False),
        ("Session API (save/update/etc)", result.session_api_hits,  False),
        ("Criteria API (LLM needed)",     result.criteria_hits,     True),
        ("createSQLQuery → native",       result.native_sql_hits,   False),
        ("Annotation changes (@TypeDef)", result.annotation_hits,   False),
        ("UserType migration (LLM needed)", result.usertype_hits,   True),
        ("HQL positional params (?→?1)",  result.hql_hits,          False),
        ("c3p0 config files",             result.c3p0_hits,         False),
        ("doWork/SP calls (low risk)",    result.dowork_hits,       False),
        ("javax.validation (check)",      result.validator_javax,   True),
    ]

    for label, hits, is_warn in sections:
        if hits:
            fn = console.warn if is_warn else console.info
            fn(f"{label}: {len(hits)} file(s)")
            for h in hits:
                console.info(f"    {h}")
        else:
            console.skip(f"{label}: none")

    if result.validator_javax:
        console.warn(
            "javax.validation found — check if hibernate-validator migration needed "
            "(javax.validation → jakarta.validation)"
        )
    if result.validator_jakarta:
        console.success("jakarta.validation already in use — validator namespace OK")

    if not result.has_anything:
        console.success("Nothing to migrate — module may already be on H7 or has no Hibernate usage")
