"""
Migration pipeline — orchestrates all transforms in the correct order.

Order:
  1. Discovery scan
  2. T1: Gradle dependency bump
  3. T2: Oracle dialect rename
  4. T3: Session API (save→persist etc)
  5. T4: Annotation changes (@TypeDef, @Where etc)
  6. T5: HQL positional params
  7. T6: LLM rewrites (Criteria, UserType) via Copilot CLI
  8. T7: c3p0 provider class
  9. Gradle compileJava check
  10. Git commit
"""

from pathlib import Path

from agent.discovery import scan, print_discovery
from transforms import t1_gradle, t2_dialect, t3_session_api, t4_annotations
from transforms import t5_hql, t6_llm_rewrites, t7_c3p0
from utils.gradle import run_compile
from utils.git import is_git_repo, has_uncommitted_changes, commit_migration
from llm.copilot import check_copilot_available


class MigrationPipeline:

    def __init__(
        self,
        module_path: Path,
        dry_run: bool,
        skip_compile: bool,
        skip_git: bool,
        skip_llm: bool,
        console,
    ):
        self.module_path = module_path
        self.dry_run = dry_run
        self.skip_compile = skip_compile
        self.skip_git = skip_git
        self.skip_llm = skip_llm
        self.console = console
        self.module_name = module_path.name
        self.total_changes = 0

    def run(self) -> bool:
        c = self.console

        # ── Pre-flight checks ─────────────────────────────────────────────────
        c.section("Pre-flight Checks")

        if not self.skip_llm:
            ok, version = check_copilot_available()
            if ok:
                c.success(f"GitHub Copilot CLI: {version}")
            else:
                c.warn(f"Copilot CLI not available: {version}")
                c.warn("LLM transforms (Criteria, UserType) will be flagged with TODOs instead")
                self.skip_llm = True

        if not self.skip_git:
            if not is_git_repo(self.module_path):
                c.warn("Not a git repository — skipping git commit")
                self.skip_git = True
            elif has_uncommitted_changes(self.module_path):
                c.warn(
                    "Uncommitted changes detected in module. "
                    "Commit or stash them before running the migrator to keep a clean rollback point."
                )
                c.warn("Proceeding anyway — git commit after migration will include pre-existing changes.")

        # ── Discovery ─────────────────────────────────────────────────────────
        c.section("Scanning Module")
        discovery = scan(self.module_path)
        print_discovery(discovery, c)

        if not discovery.has_anything:
            c.success("Nothing to do — exiting cleanly.")
            return True

        if self.dry_run:
            c.section("Dry Run — No Changes Will Be Applied")

        # ── Transform 1: Gradle ───────────────────────────────────────────────
        c.section("T1: Gradle Dependency Versions")
        n = t1_gradle.apply(self.module_path, self.dry_run, c)
        self._record(n, "Gradle")

        # ── Transform 2: Dialect ──────────────────────────────────────────────
        c.section("T2: Oracle Dialect")
        n = t2_dialect.apply(self.module_path, self.dry_run, c)
        self._record(n, "Dialect")

        # ── Transform 3: Session API ──────────────────────────────────────────
        c.section("T3: Session API (save/update/delete/createSQLQuery)")
        n = t3_session_api.apply(self.module_path, self.dry_run, c)
        self._record(n, "Session API")

        # ── Transform 4: Annotations ──────────────────────────────────────────
        c.section("T4: Annotation Changes (@TypeDef/@Where/@ForeignKey/@Type)")
        n = t4_annotations.apply(self.module_path, self.dry_run, c)
        self._record(n, "Annotations")

        # ── Transform 5: HQL ──────────────────────────────────────────────────
        c.section("T5: HQL Positional Parameters (? → ?1)")
        n = t5_hql.apply(self.module_path, self.dry_run, c)
        self._record(n, "HQL")

        # ── Transform 6: LLM (Criteria + UserType) ────────────────────────────
        c.section("T6: LLM Rewrites — Criteria API + UserType (Copilot CLI)")
        n = t6_llm_rewrites.apply(
            self.module_path, self.dry_run, c, skip_llm=self.skip_llm
        )
        self._record(n, "LLM rewrites")

        # ── Transform 7: c3p0 ─────────────────────────────────────────────────
        c.section("T7: c3p0 Provider Class")
        n = t7_c3p0.apply(self.module_path, self.dry_run, c)
        self._record(n, "c3p0")

        # ── Summary ───────────────────────────────────────────────────────────
        c.section("Transform Summary")
        c.info(f"Total changes applied: {self.total_changes}")

        if self.dry_run:
            c.info("Dry run complete — no files were modified.")
            return True

        if self.total_changes == 0:
            c.success("No changes were needed.")
            return True

        # ── Gradle compile check ──────────────────────────────────────────────
        if not self.skip_compile:
            c.section("Gradle Compile Check")
            c.info("Running ./gradlew compileJava ...")
            success, output = run_compile(self.module_path)
            if success:
                c.success("Compile succeeded.")
            else:
                c.error("Compile FAILED. Migration changes are in place but module does not compile.")
                c.error("Review the errors below, fix manually, then re-run or commit manually.")
                c.separator()
                # Print last 50 lines of output (most relevant errors)
                lines = output.strip().split('\n')
                for line in lines[-50:]:
                    print(f"  {line}")
                c.separator()
                c.warn("Git commit skipped due to compile failure.")
                return False

        # ── Git commit ────────────────────────────────────────────────────────
        if not self.skip_git:
            c.section("Git Commit")
            success, msg = commit_migration(self.module_path, self.module_name)
            if success:
                c.success(f"Committed: {msg}")
            else:
                c.warn(f"Git commit failed: {msg}")
                c.warn("Changes are applied — commit manually.")

        c.separator()
        c.success(f"Migration complete for module: {self.module_name}")

        # Remind about TODOs
        self._print_todo_reminder()

        return True

    def _record(self, n: int, label: str) -> None:
        self.total_changes += n
        if n == 0:
            self.console.skip(f"{label}: nothing to change")
        else:
            self.console.success(f"{label}: {n} change(s) applied")

    def _print_todo_reminder(self) -> None:
        c = self.console
        c.section("Manual Review Required")
        c.warn("Search for TODO[hibernate-migration] comments in the module:")
        c.info("  grep -rn 'TODO\\[hibernate-migration\\]' src/")
        c.warn("These mark locations that need manual attention:")
        c.info("  - @TypeDef removals (register type directly on field)")
        c.info("  - @ForeignKey / @Index removals")
        c.info("  - Named @Type strings that couldn't be auto-resolved")
        c.info("  - Criteria blocks too large for Copilot")
        c.info("  - UserType classes too large for Copilot")
        c.info("  - c3p0 testConnectionOnCheckin semantic review")
