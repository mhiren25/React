# Hibernate 5.5 → 7.4 Migration Agent

Fully automated Python agent that migrates a single Gradle module from Hibernate 5.5 to 7.4.

## Requirements

- Python 3.10+
- GitHub CLI with Copilot extension (`gh copilot --version` must work)
- Java 17+
- Gradle wrapper (`gradlew`) in the module or a parent directory

## Usage

```bash
# Basic — migrate a module
python migrate.py --module /path/to/your/module

# Dry run — see what would change without touching files
python migrate.py --module /path/to/your/module --dry-run

# Skip compile check (faster, use if you want to batch-fix compile errors manually)
python migrate.py --module /path/to/your/module --skip-compile

# Skip LLM (Criteria + UserType flagged with TODOs instead of auto-migrated)
python migrate.py --module /path/to/your/module --skip-llm

# Skip git commit
python migrate.py --module /path/to/your/module --skip-git
```

## What It Does

### Mechanical transforms (no LLM)
| Step | What |
|---|---|
| T1 | Bumps `hibernate-core`, `hibernate-c3p0`, `hibernate-validator` in `build.gradle` |
| T2 | Renames Oracle dialect to `OracleDialect` in `.properties` and Java config |
| T3 | Replaces `session.save()→persist()`, `update()→merge()`, `delete()→remove()`, `createSQLQuery()→createNativeQuery()` |
| T4 | Fixes `@Where→@SQLRestriction`, flags `@TypeDef`/`@ForeignKey`/`@Index` with TODOs, updates `@Type` syntax |
| T5 | Numbers bare `?` positional params in HQL strings to `?1`, `?2` etc |
| T7 | Updates c3p0 provider class name, warns on `testConnectionOnCheckin` semantics |

### LLM-assisted transforms (GitHub Copilot CLI)
| Step | What |
|---|---|
| T6a | Migrates Hibernate 5 Criteria API blocks to `CriteriaBuilder` (one method at a time) |
| T6b | Migrates `UserType` implementations to H7 `UserType<T>` interface |

### After transforms
- Runs `./gradlew compileJava` — aborts git commit if it fails
- Git commits all changes with a descriptive message (rollback with `git revert HEAD`)

## After Running

Search for items that need manual review:
```bash
grep -rn "TODO\[hibernate-migration\]" src/
```

These mark:
- `@TypeDef` removals (register type directly on field with `@Type(ClassName.class)`)
- `@ForeignKey` / `@Index` removals (use jakarta.persistence equivalents or remove)
- Named `@Type` strings that couldn't be auto-resolved
- Criteria / UserType blocks too large for Copilot (> 3000 chars)
- `testConnectionOnCheckin` — verify correct c3p0 hook for your connection init requirement

## What It Does NOT Handle

- `doWork()` / `CallableStatement` stored procedure calls — API unchanged in H7, no change needed
- `StatelessSession` — API unchanged in H7
- `javax.validation` → `jakarta.validation` — only if hibernate-validator used; check TODOs
- HQL semantic review beyond positional param fix — review complex HQL manually

## Project Structure

```
migrate.py          # CLI entry point
agent/
  pipeline.py       # Orchestrates all transforms in order
  discovery.py      # Pre-migration scanner
transforms/
  t1_gradle.py      # Gradle version bump
  t2_dialect.py     # Oracle dialect rename
  t3_session_api.py # Session method replacements
  t4_annotations.py # @TypeDef/@Where/@Type etc
  t5_hql.py         # HQL positional params
  t6_llm_rewrites.py# Criteria + UserType via Copilot CLI
  t7_c3p0.py        # c3p0 provider class
llm/
  copilot.py        # GitHub Copilot CLI backend
utils/
  console.py        # Coloured output
  files.py          # File discovery and read/write
  gradle.py         # Gradle compile runner
  git.py            # Git stage + commit
```
