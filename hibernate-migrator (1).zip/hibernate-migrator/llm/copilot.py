"""
GitHub Copilot CLI backend for LLM-assisted transforms.

PROXY SETUP
-----------
gh copilot requires a corporate proxy that is configured via your PowerShell
setup script. Because Python cannot share env vars from a separate PowerShell
window, we read proxy settings from a small config file:

    hibernate-migrator/proxy.env

That file is populated by running the helper script ONCE after your proxy
setup script:

    PowerShell> .\\tools\\export-proxy-env.ps1

Format of proxy.env (plain text, one var=value per line):
    HTTPS_PROXY=http://127.0.0.1:8080
    HTTP_PROXY=http://127.0.0.1:8080
    NO_PROXY=localhost,127.0.0.1
    GH_TOKEN=ghp_xxxxxxxxxxxx   # optional — only if gh needs explicit token

The file is gitignored by default. Never commit it.
"""

import os
import subprocess
from pathlib import Path


# Max characters to send to Copilot in a single call.
# Keeps context small and avoids timeouts.
MAX_BLOCK_CHARS = 3_000

# Path to the proxy env file — sits next to migrate.py
_PROXY_ENV_FILE = Path(__file__).parent.parent / "proxy.env"


def _load_proxy_env() -> dict[str, str]:
    """
    Load proxy environment variables from proxy.env.
    Returns a dict to merge into subprocess env.
    Returns empty dict if file not found (non-proxy environments work fine).
    """
    if not _PROXY_ENV_FILE.exists():
        return {}

    env = {}
    for line in _PROXY_ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            env[key.strip()] = value.strip()
    return env


def _build_env() -> dict[str, str]:
    """
    Build subprocess environment: current process env + proxy overrides.
    Proxy file values take precedence so they override any stale system values.
    """
    env = dict(os.environ)
    env.update(_load_proxy_env())
    return env


def _call_copilot(prompt: str) -> tuple[bool, str]:
    """
    Call GitHub Copilot CLI with a prompt, injecting proxy env vars.
    Returns (success, response_text).

    gh copilot 1.0.x uses interactive mode by default.
    We use --target shell which outputs a non-interactive result suitable
    for scripting. Falls back to 'explain' subcommand if suggest fails.
    """
    env = _build_env()

    # Primary: gh copilot suggest with --target shell (non-interactive)
    try:
        result = subprocess.run(
            ["gh", "copilot", "suggest", "--target", "shell", prompt],
            capture_output=True,
            text=True,
            timeout=90,
            env=env,
        )
        if result.returncode == 0 and result.stdout.strip():
            return True, result.stdout.strip()
    except FileNotFoundError:
        return False, "gh CLI not found — ensure GitHub CLI is on PATH"
    except subprocess.TimeoutExpired:
        return False, "gh copilot suggest timed out (90s)"

    # Fallback: gh copilot explain (works differently but may return useful text)
    try:
        result2 = subprocess.run(
            ["gh", "copilot", "explain", prompt],
            capture_output=True,
            text=True,
            timeout=90,
            env=env,
        )
        if result2.returncode == 0 and result2.stdout.strip():
            return True, result2.stdout.strip()

        err = result2.stderr or result.stderr or "No output from Copilot CLI"
        return False, err

    except subprocess.TimeoutExpired:
        return False, "gh copilot explain timed out (90s)"


def check_copilot_available() -> tuple[bool, str]:
    """
    Verify gh copilot is reachable with the proxy env injected.
    Returns (available, description).
    """
    env = _build_env()
    proxy_loaded = _PROXY_ENV_FILE.exists()

    try:
        result = subprocess.run(
            ["gh", "copilot", "--version"],
            capture_output=True,
            text=True,
            timeout=15,
            env=env,
        )
        if result.returncode == 0:
            version = result.stdout.strip()
            proxy_note = f" (proxy loaded from proxy.env)" if proxy_loaded else " (no proxy.env — direct connection)"
            return True, f"{version}{proxy_note}"
        return False, f"gh copilot returned non-zero: {result.stderr.strip()}"

    except FileNotFoundError:
        return False, "gh CLI not found on PATH"
    except subprocess.TimeoutExpired:
        return False, (
            "gh copilot timed out — proxy may not be running. "
            "Start your PowerShell proxy setup script first, then run export-proxy-env.ps1"
        )


def proxy_env_status() -> str:
    """Human-readable status of the proxy.env file."""
    if not _PROXY_ENV_FILE.exists():
        return (
            f"proxy.env not found at {_PROXY_ENV_FILE}\n"
            f"Run tools/export-proxy-env.ps1 from your proxy PowerShell window first."
        )
    env = _load_proxy_env()
    lines = [f"proxy.env loaded ({len(env)} vars):"]
    for k, v in env.items():
        # Mask tokens
        display = v if "TOKEN" not in k.upper() and "KEY" not in k.upper() else v[:8] + "***"
        lines.append(f"  {k}={display}")
    return "\n".join(lines)


# ── Prompt functions ──────────────────────────────────────────────────────────

def migrate_criteria_block(block: str) -> tuple[bool, str]:
    """Ask Copilot to migrate a Hibernate 5 Criteria block to CriteriaBuilder."""
    if len(block) > MAX_BLOCK_CHARS:
        return False, f"Block too large ({len(block)} chars) — split manually"

    prompt = (
        "Migrate this Hibernate 5 Criteria API Java code block to Hibernate 7 CriteriaBuilder. "
        "Rules: Pure Hibernate native API no JPA no Spring no EntityManager. "
        "Use session.getCriteriaBuilder() keep existing session variable name. "
        "Oracle database. Preserve all result variable names. "
        "Output ONLY the migrated Java code block no explanation no markdown fences. "
        "Add a TODO comment for any Restriction with no direct equivalent. "
        f"Code to migrate: {block}"
    )
    return _call_copilot(prompt)


def migrate_usertype_class(class_source: str) -> tuple[bool, str]:
    """Ask Copilot to migrate a UserType implementation to H7 interface."""
    if len(class_source) > MAX_BLOCK_CHARS:
        return False, f"Class too large ({len(class_source)} chars) — migrate manually"

    prompt = (
        "Migrate this Hibernate 5 UserType Java class to the Hibernate 7 UserType generic interface. "
        "Key interface changes: nullSafeGet takes ResultSet and int position not String array names and SharedSessionContractImplementor. "
        "nullSafeSet takes PreparedStatement and value and int index and SharedSessionContractImplementor. "
        "sqlTypes int array replaced by getSqlType returning single int. "
        "returnedClass now returns typed Class. "
        "SessionImplementor replaced by SharedSessionContractImplementor. "
        "Rules: Preserve exact type conversion logic. Do not change class name. "
        "Pure Hibernate no JPA no Spring. "
        "Output ONLY the migrated Java class no explanation no markdown fences. "
        f"Class to migrate: {class_source}"
    )
    return _call_copilot(prompt)


def review_hql_query(hql: str) -> tuple[bool, str]:
    """Ask Copilot to flag H7 incompatibilities in an HQL string."""
    prompt = (
        "Review this HQL query for Hibernate 7 compatibility. "
        "Context: Hibernate native Session.createQuery() no JPA Oracle database. "
        "Flag ONLY these issues by adding inline comments with the fix: "
        "1. Positional params using bare question mark style which must be numbered like ?1 ?2 in H7. "
        "2. Function syntax that changed between Hibernate 5 and Hibernate 7. "
        "3. Join syntax that will cause H7 parse errors. "
        "Output ONLY the query with inline fix comments. No explanation. "
        f"HQL: {hql}"
    )
    return _call_copilot(prompt)
